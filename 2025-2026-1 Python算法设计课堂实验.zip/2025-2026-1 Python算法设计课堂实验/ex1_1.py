# 导入math模块，用于后续计算平方根操作
import math
# 定义函数get_primes，参数n用于指定要找�?1到n范围内的质数
def get_primes(n):
    # 创建一个空列表primes，用来存储找到的质数
    primes = []
    # 遍历�?2到n（包含n）的每个整数num
    for num in range(2, n + 1):
        # 先假设当前数num是质数，将is_prime标记为True
        is_prime = True
        # 遍历�?2到num的平方根（取整后�?1）的每个整数i
        for i in range(2, int(math.sqrt(num)) + 1):
            # 如果num能被i整除，说明num不是质数
            if num % i == 0:
                # 将is_prime标记为False，表示不是质�?
                is_prime = False
                # 一旦确定不是质数，就跳出内层循环，节省计算资源
                break
        # 如果经过内层循环后is_prime仍为True，说明num是质�?
        if is_prime:
            # 将质数num添加到primes列表�?
            primes.append(num)
    # 函数执行完毕，返回存储质数的列表primes
    return primes

# 通过input函数获取用户输入的整数，并转换为int类型赋值给n
n = int(input("请输入一个整数n:"))
# 调用get_primes函数，传入n，获取1到n范围内的质数列表，赋值给primes_list
primes_list = get_primes(n)
# 遍历primes_list中的每个质数
for prime in primes_list:
    # 打印每个质数
    print(prime)
