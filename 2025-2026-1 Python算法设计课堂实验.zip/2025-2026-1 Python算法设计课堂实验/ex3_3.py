#定义名为calc的函数，参数n是要处理的自然数，process用于存储计算过程
def calc(n,process= None):
    #当第一次调用函数，process为默认的None
    if process is None:
        #初始化一个空列表，用于存放每一步计算过程
        process = []
    #递归终止条件：当n等于1时
    if n == 1 :
        #返回存放好运算过程的列表，结束递归
        return process
    #判断自然数是否是奇数
    if n % 2 == 1:
        #奇数运算规则：乘3加1，计算结果赋值res
        res = n * 3 + 1
        #将这一步计算过程以字符串形式添加到列表
        process.append(f"{n} * 3 + 1 = {res}")
        #递归调用calc函数，传入新的数和存储过程
        return calc(res,process)
    #否则自然数为偶数
    else:
        #偶数运算规则：整除2，计算结果赋值res
        res = n // 2
        # 将这一步计算过程以字符串形式添加到列表
        process.append(f"{n} / 2 = {res}")
        # 递归调用calc函数，传入新的数和存储过程
        return calc(res,process)
#定义测试自然数17
n = 17
#调用函数运算，结果赋值给result
result = calc(n)
#打印运算过程列表
for step in result:
    print(step)