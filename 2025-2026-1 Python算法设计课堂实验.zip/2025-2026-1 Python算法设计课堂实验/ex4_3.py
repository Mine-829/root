# 二叉树节点类：定义二叉树的基本节点结构
class Node:
    # 初始化节点，传入节点数据
    def __init__(self, data):
        self.data = data  # 节点存储的数据
        self.left = None  # 左孩子节点，初始为空
        self.right = None  # 右孩子节点，初始为空


# 二叉树类：封装二叉树的操作方法
class BinTree:
    # 初始化二叉树，根节点默认为空
    def __init__(self):
        self.root = None  # 二叉树的根节点

    # 设置二叉树的根节点（仅当根节点为空时生效）
    def set_root(self, root_node):
        if self.root is None:
            self.root = root_node

    # 为指定父节点添加左孩子节点
    def add_left(self, parent_node, left_node):
        parent_node.left = left_node

    # 为指定父节点添加右孩子节点
    def add_right(self, parent_node, right_node):
        parent_node.right = right_node

    # 前序遍历方法（根→左→右）
    # node: 当前遍历的节点，result: 存储遍历结果的列表
    def pre_order(self, node, result):
        if node is None:  # 递归终止条件：节点为空
            return
        result.append(node.data)  # 先访问根节点，存入结果
        self.pre_order(node.left, result)  # 递归遍历左子树
        self.pre_order(node.right, result)  # 递归遍历右子树

    # 中序遍历方法（左→根→右）
    def in_order(self, node, result):
        if node is None:
            return
        self.in_order(node.left, result)  # 先递归遍历左子树
        result.append(node.data)  # 再访问根节点
        self.in_order(node.right, result)  # 最后递归遍历右子树

    # 后序遍历方法（左→右→根）
    def post_order(self, node, result):
        if node is None:
            return
        self.post_order(node.left, result)  # 先递归遍历左子树
        self.post_order(node.right, result)  # 再递归遍历右子树
        result.append(node.data)  # 最后访问根节点


# 主程序入口：构建二叉树并执行遍历
if __name__ == "__main__":
    # 创建二叉树的所有节点，每个节点对应题目中的数值
    n1 = Node(1)
    n2 = Node(2)
    n3 = Node(3)
    n4 = Node(4)
    n5 = Node(5)
    n6 = Node(6)
    n7 = Node(7)
    n8 = Node(8)
    n9 = Node(9)
    n10 = Node(10)
    n11 = Node(11)
    n12 = Node(12)
    n13 = Node(13)
    n14 = Node(14)
    n15 = Node(15)
    n16 = Node(16)

    # 初始化二叉树对象
    bt = BinTree()
    # 设置根节点为n1
    bt.set_root(n1)

    # 构建二叉树的节点关系：为每个父节点添加左右子节点
    bt.add_left(n1, n2)
    bt.add_right(n1, n3)

    bt.add_left(n2, n4)
    bt.add_right(n2, n5)

    bt.add_left(n3, n6)
    bt.add_right(n3, n7)

    bt.add_left(n4, n8)
    bt.add_right(n4, n9)

    bt.add_right(n5, n10)

    bt.add_left(n6, n11)

    bt.add_left(n7, n12)

    bt.add_left(n11, n13)
    bt.add_right(n11, n14)

    bt.add_left(n12, n15)
    bt.add_right(n12, n16)

    # 执行前序遍历并输出结果
    pre_result = []  # 初始化前序结果列表
    bt.pre_order(bt.root, pre_result)  # 从根节点开始前序遍历
    print("前序遍历:", pre_result)  # 打印前序遍历结果

    # 执行中序遍历并输出结果
    in_result = []
    bt.in_order(bt.root, in_result)
    print("中序遍历:", in_result)

    # 执行后序遍历并输出结果
    post_result = []
    bt.post_order(bt.root, post_result)
    print("后序遍历:", post_result)
