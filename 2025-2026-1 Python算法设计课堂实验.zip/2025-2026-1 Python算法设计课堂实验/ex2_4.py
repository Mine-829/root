# 定义选择排序函数，参数ls为待排序的列表
def selection_sort(ls):
    # 获取列表长度
    length=len(ls)
    # 打印初始状态，未排序是整个列表，已排序区为空
    print(f"初始,未排序区和已排序区分为:{ls},[]")
    # 循环length次，每轮确定一个最大元素的位置
    for i in range(length):
    # 计算当前轮次中，最大元素要放置的目标位置
        max_pos = length - 1 - i
    # 初始假设未排序区最后一个元素是最大的，记录其索引
        max_index = max_pos
    # 遍历未排序区（前max_pos + 1元素），寻找真正的最大元素
        for j in range(max_pos + 1):
            if ls[j] > ls[max_index]:
                max_index = j
       #将寻找到的最大元素与目标位置的元素互换，是最大元素进入已排序区
        ls[max_index],ls[max_pos]=ls[max_pos], ls[max_index]
         # 打印本轮排序后的状态：
        # 未排序区为列表的前（length - i）个元素（随着轮次增加，未排序区长度逐渐减少）
        # 已排序区为列表的剩余元素（随着轮次增加，已排序区长度逐渐增加）
        print(f"第{i+1}轮排序后,未排序区和已排序区分为:{ls[:length-i]},{ls[length-i:]}")
# 定义待排序的列表
ls=[9,8,6,7,2,5,4,1,3]
# 调用选择排序函数对列表进行排序
selection_sort(ls)
# 打印排序完成后的最终列表
print(ls)
