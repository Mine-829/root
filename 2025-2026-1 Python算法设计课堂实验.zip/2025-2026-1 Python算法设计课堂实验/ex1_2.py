def encrypt(plain_text):
    # 用于存储加密后的字符串
    result = ""
    for char in plain_text:
        # 空格保持不变
        if char == " ":
            result += char
        else:
            # 处理大写字母
            if char.isupper():
                # 计算转换后字符的 ASCII 码，考虑折返
                shifted = (ord(char) - ord('A') + 3) % 26 + ord('A')
                result += chr(shifted)
            # 处理小写字母
            else:
                shifted = (ord(char) - ord('a') + 3) % 26 + ord('a')
                result += chr(shifted)
    return result
# 调用函数并输出结果
print(encrypt("Hello World"))