#定义一个名为reverse_str的函数，参数s是要进行反转的字符串
def reverse_str(s):
    #递归终止条件：当字符串长度小于等于1时(空串或者只有一个字符)
    if len(s) <= 1:
        #返回它本身
        return s
    #计算字符串中间索引，用整除确保整数索引
    mid = len(s) // 2
    #截取字符串左半部分（从开头到mid位置前的子串）
    left = s[:mid]
    # #截取字符串右半部分（从mid位置到结尾的子串）
    right = s[mid:]
    #递归处理：分别反转右半部分和左半部分，再将其拼接
    return reverse_str(right)+reverse_str(left)
#定义测试字符串
s = "How are you!"
#调用函数反转字符串，结果赋值给result
result = reverse_str(s)
#打印结果
print(f"字符串{s}反转后的结果为：{result}")