#定义一个名叫avg_divide的函数，参数ls是要计算平均值的数字列表
def avg_divide(ls):
    #判断列表是否为空
    if len(ls) == 0:
        #如果是空列表，空列表的平均值返回0
        return 0
    #递归终止条件：当列表的长度为1时（列表内只有一个元素）
    if len(ls) == 1:
        #单个元素的平均值是它本身
        return ls[0]
    #找到列表的中间位置，用整除得到整数索引
    mid = len(ls) // 2
    #计算左部分列表的中间值，ls[:mid]代表从列表开头到mid位置前的子列表
    left_avg = avg_divide(ls[:mid])
    # 计算右部分列表的中间值，ls[mid:]代表从mid位置到列表结尾的子列表
    right_avg = avg_divide(ls[mid:])
    #先分别算出两半部分的综合再除以整个列表的元素个数，得到结果
    return (left_avg * len(ls[:mid])+right_avg * len(ls[mid:])) / len(ls)
#定义测试列表
ls = [1,2,3,4,5,6]
#调用函数计算
result = avg_divide(ls)
#打印结果
print(f"数字列表{ls}的平均值为：{result}")