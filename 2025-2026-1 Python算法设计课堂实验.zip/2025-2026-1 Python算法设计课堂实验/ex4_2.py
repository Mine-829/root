#导入Python的队列模块，用于实现队列
from collections import deque
#定义一个函数名为level_order，用于实现层序遍历
def level_order(tree,root):
    #如果根节点为空
    if root is None:
        #返回空列表
        return []
#初始化一个列表，用于存储每层的节点结果
    levels = []
    #创建队列，初始时将根节点加入队列
    queue = deque([root])
    #初始化层数=1
    level_num = 1
#当队列不为空时，持续遍历
    while queue:
        #获取当前队列的长度，即节点数量
        level_size = len(queue)
        #初始化列表，存储当前层节点结果
        current_level = []
#遍历当前层的所有节点
        for _ in range(level_size):
            #从队列左侧弹出一个节点
            node = queue.popleft()
            #将该节点加入当前层的节点列表
            current_level.append(node)
#如果当前节点在树的字典有子节点
            if node in tree:
                #把所有子节点加入队列
                queue.extend(tree[node])
#将当前层层数和节点列表存入结果列表
        levels.append((level_num,current_level))
        #层数+1，处理下一层
        level_num += 1
#返回层序遍历的结果
    return levels
#创建测试多叉树
multi_tree = {
    1:[2,3,4],
    2:[5,6],
    3:[7],
    4:[8,9,10],
    5:[11],
    6:[12],
    7:[13,14],
    14:[15,16,17]
}
#调用level_order函数，从根节点1开始层序遍历
level_result = level_order(multi_tree,1)
#遍历层序遍历的结果并输出
for level_num,nodes in level_result:
    print(f"{level_num}->{','.join(map(str,nodes))}")