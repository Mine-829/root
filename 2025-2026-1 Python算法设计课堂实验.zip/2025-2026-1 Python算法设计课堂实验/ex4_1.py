#定义一个函数名为dfs_paths
def dfs_paths(tree,node,current_path,result):
    #将当前节点转换为字符串并添加到当前路径列表中
    current_path.append(str(node))
#判断当前节点是否为叶子节点：1.节点不在tree的键中；2.节点在tree中但子节点列表为空
    if node not in tree or tree[node] == []:
        #将当前路径用“->”拼接成字符串，添加到结果列表
        result.append("->".join(current_path))
#如果不是叶子节点
    else:
        #遍历当前节点的所有子节点
        for child in tree[node]:
            #递归调用dfs_paths，继续遍历子节点
            dfs_paths(tree,child,current_path,result)
#移除当前节点，处理其他分支
    current_path.pop()
#创建测试多叉树
multi_tree = {
    1:[2,3,4],
    2:[5,6],
    3:[7],
    4:[8,9,10],
    5:[11],
    6:[12],
    7:[13,14],
    14:[15,16,17]
}
#创建空列表，存储所有路径结果
paths_result = []
#调用dfs_paths，从根节点1开始遍历
dfs_paths(multi_tree,1,[],paths_result)
#遍历所有路径结果并输出
for path in paths_result:
    print(f"-1>{path[2:]}")