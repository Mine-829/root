const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()

exports.main = async (event, context) => {
  const { action } = event
  console.log("【userCrud入口】接收请求event:", event)

  try {
    if (action === "login") {
      const { studentId, pwd } = event
      const sid = Number(studentId || 0)
      const res = await db.collection("user")
        .where({
          studentId: sid,
          password: pwd || ""
        })
        .get()
      if (res.data.length === 0) {
        return { code: -1, msg: "学号或密码错误" }
      }
      return {
        code: 0,
        userInfo: res.data[0]
      }
    }

    if (action === "getUserList") {
      const res = await db.collection("user").get()
      return {
        code: 0,
        data: res.data
      }
    }

    if (action === "register") {
      const { studentId, realName, className, pwd } = event
      const sid = Number(studentId || 0)
      const existRes = await db.collection("user")
        .where({ studentId: sid })
        .get()
      if (existRes.data.length > 0) {
        return { code: -1, msg: "该学号已存在，无法重复新增" }
      }
      await db.collection("user").add({
        data: {
          studentId: sid,
          realName: realName || "",
          className: className || "",
          password: pwd || "",
          role: "member"
        }
      })
      return { code: 0, msg: "用户新增成功" }
    }

    // 编辑用户信息
    if (action === "editUser") {
      const { _id, update } = event
      if (!_id) return { code: -1, msg: "缺少记录ID" }
      await db.collection("user")
        .doc(_id)
        .update({ data: update })
      return { code: 0, msg: "修改成功" }
    }

    // 删除用户
    if (action === "delUser") {
      const { _id } = event
      if (!_id) return { code: -1, msg: "缺少记录ID" }
      await db.collection("user").doc(_id).remove()
      return { code: 0, msg: "删除成功" }
    }

    if (action === "admin-user") {
      const { studentId, newRole, operateAdmin } = event
      const sid = Number(studentId || 0)
      // 先判断学号是否存在
      const check = await db.collection("user").where({studentId: sid}).get()
      if(check.data.length === 0){
        return { code: -1, msg: "该学号用户不存在" }
      }
      await db.collection("user")
        .where({ studentId: sid })
        .update({
          data: { role: newRole || "member" }
        })
      return { code: 0, msg: "权限修改成功" }
    }

    return { code: -99, msg: "无效操作类型" }

  } catch (err){
    console.error("【userCrud捕获异常】", err)
    return { code: -99, msg: "服务异常：" + (err.message || "未知错误") }
  }
}