const cloud = require('wx-server-sdk')
const XLSX = require('xlsx')
// 初始化云环境
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()
const _ = db.command

// 积分规则常量
const SCORE_CFG = {
  absentScore: 2,
  failCourseScore: 5,
  disciplineScore: 3,
  volunteerPerHour: 0.25,
  volunteerMax: 8,
  activityPerItem: 2,
  prizePerItem: 3,
  postScore: {
    "班长": 10,
    "团支书": 10,
    "部长": 8,
    "副部长": 6,
    "委员": 4,
    "助班": 3,
    "副班长": 3
  }
}

/**
 * 清洗文本：去除换行、制表、零宽非法字符
 */
function cleanSafeText(text) {
  if (text === null || text === undefined) return ""
  let str = String(text)
  str = str.replace(/[\x00-\x1F\x7F-\x9F\n\r\t\v\u200b\u200c\u200d]/g, "")
  return str.trim()
}

/**
 * 兼容表头前后空格获取单元格值
 */
function getCellValue(row, keyList) {
  for (const key of keyList) {
    if (row[key] !== undefined) return row[key]
    if (row[` ${key}`] !== undefined) return row[` ${key}`]
    if (row[`${key} `] !== undefined) return row[`${key}`]
  }
  return ""
}

/**
 * 解析排名 2/27 → 返回数字名次，空返回9999
 */
function parseRankText(rankStr) {
  const s = cleanSafeText(rankStr)
  if (!s || !s.includes('/')) return 9999
  const num = s.split('/')[0].trim()
  return Number(num) || 9999
}

/**
 * 志愿时长 5小时7分钟 → 小时浮点数
 */
function parseVolText(timeStr) {
  const s = cleanSafeText(timeStr)
  if (!s) return 0
  let h = 0, m = 0
  const hMatch = s.match(/(\d+)小时/)
  const mMatch = s.match(/(\d+)分钟/)
  if (hMatch) h = Number(hMatch[1])
  if (mMatch) m = Number(m)
  return h + m / 60
}

/**
 * 拆分活动/获奖条目，返回干净数组
 */
function splitItemList(str) {
  const s = cleanSafeText(str)
  if (!s) return []
  let t = s.replace(/<br\s*\/?>/g, '、')
  return t.split(/、|，/).filter(item => cleanSafeText(item))
}

exports.main = async (event) => {
  const { action, excelFileID } = event
  if (!excelFileID) {
    return { code: -1, msg: "失败：未接收到上传文件ID" }
  }

  try {
    if (action === "batchImportRaw") {
      // 1. 下载解析Excel
      const fileRes = await cloud.downloadFile({ fileID: excelFileID })
      const buffer = fileRes.fileContent
      const workbook = XLSX.read(buffer, { type: "buffer", raw: false })
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
      const dataList = XLSX.utils.sheet_to_json(firstSheet)
      if (!dataList || dataList.length === 0) {
        return { code: -1, msg: "失败：Excel表格无有效数据" }
      }

      // 2. 清空临时集合
      try {
        await db.collection("excel_raw").where({ _id: _.exists(true) }).remove()
        console.log("临时表excel_raw清空完成")
      } catch (e) {
        console.log("excel_raw不存在，跳过清空")
      }

      let successCount = 0
      let failList = []

      for (let i = 0; i < dataList.length; i++) {
        const row = dataList[i]
        const rowNum = i + 2
        try {
          // 基础字段清洗
          const realName = cleanSafeText(getCellValue(row, ["姓名"]))
          const className = cleanSafeText(getCellValue(row, ["班级"]))
          if (!realName) continue

          // ========== 第一步：加载扣分项（是否旷课/挂科/违纪）==========
          const isAbsent = cleanSafeText(getCellValue(row, ["是否旷课"])) === "是"
          const absent = isAbsent ? SCORE_CFG.absentScore : 0

          const isFail = cleanSafeText(getCellValue(row, ["是否挂科"])) === "是"
          const failCourse = isFail ? SCORE_CFG.failCourseScore : 0

          const isDis = cleanSafeText(getCellValue(row, ["是否违纪"])) === "是"
          const disciplinePunish = isDis ? SCORE_CFG.disciplineScore : 0

          // ========== 第二步：加载成绩排名加分 ==========
          const studyRank = parseRankText(getCellValue(row, ["学习成绩排名"]))
          let scholarHonor = 0
          if (studyRank <= 10) scholarHonor = 10
          else if (studyRank <= 20) scholarHonor = 7
          else if (studyRank <= 35) scholarHonor = 4
          else if (studyRank <= 50) scholarHonor = 1

          const zongRank = parseRankText(getCellValue(row, ["综测排名"]))
          const subjectComp = zongRank <= 20 ? 8 : 0

          // ========== 第三步：职位、志愿、活动、获奖完整业务逻辑 ==========
          // 职位加分
          const postStr = cleanSafeText(getCellValue(row, ["职位（班级/部门）"]))
          let postScore = 0
          Object.entries(SCORE_CFG.postScore).forEach(([name, score]) => {
            if (postStr.includes(name) && score > postScore) postScore = score
          })

          // 志愿时长计算
          const hourTotal = parseVolText(getCellValue(row, ["志愿总时长"]))
          let volunteer = hourTotal * SCORE_CFG.volunteerPerHour
          if (volunteer > SCORE_CFG.volunteerMax) volunteer = SCORE_CFG.volunteerMax

          // 活动、获奖拆分统计条数
          const actArr = splitItemList(getCellValue(row, ["参与学校、学院的活动（请罗列）"]))
          const prizeArr = splitItemList(getCellValue(row, ["获奖情况"]))
          const activityScore = actArr.length * SCORE_CFG.activityPerItem
          const innovateBiz = prizeArr.length * SCORE_CFG.prizePerItem
          const socialWork = postScore + activityScore

          // 组装入库对象：全部数值强制Number，字符串全清洗，无undefined/null
          const writeData = {
            realName,
            className,
            socialWork: Number(socialWork),
            subjectComp: Number(subjectComp),
            innovateBiz: Number(innovateBiz),
            scholarHonor: Number(scholarHonor),
            partyClass: 0,
            volunteer: Number(volunteer),
            redHeart: 0,
            socialPractice: 0,
            interExchange: 0,
            peerHelp: 0,
            wrongSpeech: 0,
            failCourse: Number(failCourse),
            absent: Number(absent),
            netViolate: 0,
            disciplinePunish: Number(disciplinePunish),
            oneVoteNo: 0,
            createTime: new Date()
          }

          // 单条写入数据库
          await db.collection("excel_raw").add({ data: writeData })
          successCount++
          console.log(`第${rowNum}行【${realName}】写入成功`)

        } catch (singleErr) {
          console.error(`第${rowNum}行写入失败详情：`, singleErr)
          failList.push(`第${rowNum}行：${singleErr.message}`)
        }
      }

      // 返回导入结果
      if (failList.length === 0) {
        return {
          code: 0,
          msg: `✅ 表格解析完成，共${successCount}条原始数据`,
          count: successCount
        }
      } else {
        return {
          code: 0,
          msg: `成功${successCount}条，失败${failList.length}条：\n${failList.join('\n')}`,
          count: successCount
        }
      }
    }

    return { code: -99, msg: "不支持的操作类型" }
  } catch (globalErr) {
    console.error("云函数全局异常：", globalErr)
    return { code: -1, msg: "解析失败：" + globalErr.message }
  }
}