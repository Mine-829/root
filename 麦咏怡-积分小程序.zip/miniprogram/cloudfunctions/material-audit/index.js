const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()

exports.main = async (event) => {
  const { action } = event
  try {
    // 学生提交佐证材料
    if (action === "submit") {
      const { userId, realName, studentId, className, type, content, imgFileIds, docFileIds } = event
      await db.collection("material").add({
        data: {
          userId,
          realName,
          studentId,
          className,
          type,
          content,
          imgFileIds,
          docFileIds,
          createTime: db.serverDate(),
          auditStatus: "pending"
        }
      })
      return { code: 0, msg: "提交成功" }
    }

    // 学生查询自己的材料（仅30天内）
    if (action === "getUserMaterial") {
      const { userName } = event
      // 计算30天前时间
      const thirtyDayAgo = new Date()
      thirtyDayAgo.setDate(thirtyDayAgo.getDate() - 30)
      const matRes = await db.collection("material")
        .where({ 
          realName: userName,
          createTime: db.command.gte(thirtyDayAgo)
        })
        .orderBy("createTime", "desc")
        .get()
      return { code: 0, data: matRes.data }
    }

    // 管理员查询全部材料（仅展示近30天提交记录）
    if (action === "listAll") {
      const thirtyDayAgo = new Date()
      thirtyDayAgo.setDate(thirtyDayAgo.getDate() - 30)
      const res = await db.collection("material")
        .where({
          createTime: db.command.gte(thirtyDayAgo)
        })
        .orderBy("createTime", "desc")
        .get()
      return { code: 0, data: res.data }
    }

    // 审核操作：通过/驳回
    if (action === "audit") {
      const { _id, status, auditBy } = event
      await db.collection("material").doc(_id).update({
        data: {
          auditStatus: status,
          auditBy: auditBy,
          auditTime: db.serverDate()
        }
      })
      return { code: 0, msg: "审核成功" }
    }

    // 无匹配操作
    return { code: -99, msg: "无效操作" }
  } catch (err){
    console.error("材料云函数异常", err)
    return { code: -1, msg: "操作失败：" + err.message }
  }
}