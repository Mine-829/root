const cloud = require('wx-server-sdk')
const XLSX = require('xlsx')

// 初始化云环境
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()
const _ = db.command

// ===================== 全局学期配置（前端同步getTermOptions来源） =====================
const TERM_OPTIONS = [
  "2024-2025上",
  "2024-2025下",
  "2025-2026上",
  "2025-2026下",
  "2026-2027上",
  "2026-2027下"
]
function getTermOptions() {
  return TERM_OPTIONS
}

// ===================== 学期格式化工具（导入Excel自动转换 2025上 → 2025-2026上） =====================
function formatTerm(term) {
  const reg = /^(\d{4})(上|下)$/;
  const match = term.match(reg);
  if (match) {
    const y = match[1];
    return `${y}-${+y + 1}${match[2]}`;
  }
  return term;
}

// ===================== 数据库批量修复旧学期（一次性执行Action：fixAllTerm） =====================
async function fixAllTerm() {
  const termOptions = getTermOptions()
  const snap = await db.collection("score").get();
  const updateTasks = []
  for (let item of snap.data) {
    let newTerm = item.term;
    const m = item.term.match(/^(\d{4})(上|下)$/);
    if (m) {
      newTerm = `${m[1]}-${+m[1]+1}${m[2]}`;
    }
    // 仅修复合法范围内学期，防止脏数据
    if (termOptions.includes(newTerm)) {
      updateTasks.push(
        db.collection("score").doc(item._id).update({
          data: { term: newTerm }
        })
      )
    }
  }
  await Promise.all(updateTasks)
  return { fixCount: updateTasks.length }
}

// ===================== 严格对齐综测评分规则方案 =====================
const RULES = {
  rank: { top5: 6, top10: 3, top20: 1 },
  socialWork: {
    leader: 5,       // 校级主席/部长
    subLeader: 5,    // 校级副主席/副部长
    colLeader: 4,    // 院级主席/部长/学习部部长
    classLeader: 3,  // 班长/团支书/副班长
    common: 3        // 其他班委/干事/助理
  },
  perActivity: {
    party: 5,        // 党课学习
    red: 3,          // 红心活动
    practice: 5,     // 社会实践基础分
    inter: 2,        // 国际交流
    peer: 2          // 同辈互助
  },
  volunteer: { rate: 0.25, cap: 8.0 },
  acCap: 40,
  ptCap: 60
}

// ===================== 通用防御性文本清洗工具 =====================
function cleanSafeText(text) {
  if (text === null || text === undefined) return ""
  let str = String(text).replace(/[\x00-\x1F\x7F-\x9F\n\r\t\v\u200b\u200c\u200d]/g, "")
  return str.trim()
}

// 严格比对表头键值（完全适配你的Excel表头）
function getCellValue(row, keyList) {
  for (const key of keyList) {
    if (row[key] !== undefined) return row[key]
    if (row[` ${key}`] !== undefined) return row[` ${key}`]
    if (row[`${key} `] !== undefined) return row[`${key}`]
  }
  // 针对长表头做特殊模糊前缀匹配
  for (const actualKey of Object.keys(row)) {
    const cleanKey = actualKey.trim()
    for (const targetKey of keyList) {
      if (cleanKey.startsWith(targetKey) && targetKey.length >= 4) {
        return row[actualKey]
      }
    }
  }
  return ""
}

// 解析排名百分比并返回对应得分
function getRankScore(rankStr) {
  const s = cleanSafeText(rankStr)
  if (!s || !s.includes('/')) return 0
  const [nowStr, totalStr] = s.split('/')
  const now = Number(cleanSafeText(nowStr))
  const total = Number(cleanSafeText(totalStr))
  if (isNaN(now) || isNaN(total) || total <= 0) return 0
  const percent = (now / total) * 100
  if (percent <= 5) return RULES.rank.top5
  if (percent <= 10) return RULES.rank.top10
  if (percent <= 20) return RULES.rank.top20
  return 0
}

// 解析班级或学院职务得分
function getPostScore(postText) {
  const s = cleanSafeText(postText)
  if (!s || s === "无") return 0
  if (s.includes("校级") && (s.includes("主席") || s.includes("部长"))) return RULES.socialWork.leader
  if (s.includes("校级") && (s.includes("副主席") || s.includes("副部长"))) return RULES.socialWork.subLeader
  if (s.includes("院级") || s.includes("部长") || s.includes("会长") || s.includes("组长")) return RULES.socialWork.colLeader
  if (s.includes("班长") || s.includes("团支书") || s.includes("副班长")) return RULES.socialWork.classLeader
  if (s.includes("委员") || s.includes("干事") || s.includes("助理") || s.includes("志愿者")) return RULES.socialWork.common
  return 0
}

// 解析志愿时长文本：总时长按半小时四舍五入，最终换算 0.25/小时，上限8分
function parseVolText(timeStr) {
  const s = cleanSafeText(timeStr)
  if (!s) return 0

  let h = 0, m = 0
  const hMatch = s.match(/(\d+)小时/)
  const mMatch = s.match(/(\d+)分钟/)

  if (hMatch) h = Number(hMatch[1])
  if (mMatch) m = Number(mMatch[1])

  // 纯数字浮点格式兼容（如 2.3 代表2.3小时）
  if (!hMatch && !mMatch) {
    const pureNum = parseFloat(s)
    if (!isNaN(pureNum)) {
      h = Math.floor(pureNum)
      m = Math.round((pureNum % 1) * 60)
    }
  }

  // 总分钟数
  const totalMinutes = h * 60 + m
  // 按30分钟四舍五入
  const roundedHours = Math.round(totalMinutes / 30) * 0.5
  return roundedHours
}

function splitItemList(str) {
  const s = cleanSafeText(str)
  if (!s || s === "无") return []
  let t = s.replace(/<br\s*\/?>/g, '、').replace(/\n/g, '、')
  return t.split(/、|.|:|;/).filter(item => cleanSafeText(item))
}

// ===================== 统一计算衍生字段 studyAbility / partyGrow / deductScore / totalScore =====================
function calcScoreItem(item) {
  const sw = Number(item.socialWork ?? 0);
  const ac = Number(item.academicCompetition ?? 0);
  const ib = Number(item.innovationEntrepreneurship ?? 0);
  const sh = Number(item.scholarshipHonor ?? 0);

  const pc = Number(item.partyClassStudy ?? 0);
  const vol = Number(item.volunteerService ?? 0);
  const rh = Number(item.redHeartActivity ?? 0);
  const sp = Number(item.socialPractice ?? 0);
  const ie = Number(item.internationalExchange ?? 0);
  const ph = Number(item.peerMutualAid ?? 0);

  const ws = Number(item.inappropriateRemarks ?? 0);
  const fc = Number(item.failedCourse ?? 0);
  const ab = Number(item.unexcusedAbsence ?? 0);
  const nv = Number(item.networkViolation ?? 0);
  const dp = Number(item.disciplinarySanction ?? 0);
  const veto = Number(item.oneVoteVeto ?? 0);

  const studyRaw = sw + ac + ib + sh;
  const studyAbility = Math.min(studyRaw, 40);

  const partyRaw = pc + vol + rh + sp + ie + ph;
  const partyGrow = Math.min(partyRaw, 60);

  const deductScore = ws + fc + ab + nv + dp + veto;
  const totalScore = Math.max(studyAbility + partyGrow - deductScore, 0);

  return {
    ...item,
    studyAbility: Number(studyAbility.toFixed(1)),
    partyGrow: Number(partyGrow.toFixed(1)),
    deductScore: Number(deductScore.toFixed(1)),
    totalScore: Number(totalScore.toFixed(1))
  }
}

// ===================== 核心级别/荣誉精准匹配引擎 =====================
function matchLevelScore(itemText) {
  const txt = cleanSafeText(itemText)
  if (txt.includes("国家奖学金")) return 8
  if (txt.includes("国家励志奖学金")) return 6
  if (txt.includes("一等奖学金")) return 4
  if (txt.includes("二等奖学金") || txt.includes("银奖")) return 3
  if (txt.includes("三等奖学金") || txt.includes("铜奖") || txt.includes("优秀奖")) return 2

  if (txt.includes("国家级") || txt.includes("全国")) return 8
  if (txt.includes("省级") || txt.includes("省赛") || txt.includes("广东省")) return 6
  if (txt.includes("市级") || txt.includes("广州市") || txt.includes("开平市")) return 4
  if (txt.includes("校级") || txt.includes("校赛") || txt.includes("广州航海学院") || txt.includes("三好学生") || txt.includes("优秀团员") || txt.includes("优秀团干") || txt.includes("优秀学生骨干") || txt.includes("先进个人")) return 3
  if (txt.includes("院级") || txt.includes("院赛") || txt.includes("学院") || txt.includes("优秀学员")) return 2
  return 3
}

function getAwardCategoryScores(awardList) {
  let comp = 0, innov = 0, honor = 0, practicePrize = 0

  for (const item of awardList) {
    const txt = cleanSafeText(item)
    if (txt.includes("HarmonyOS") || txt.includes("开发师") || txt.includes("开发者") || txt.includes("创新大赛") || txt.includes("大创") || txt.includes("创业") || txt.includes("立项") || txt.includes("青蓝E")) {
      innov += matchLevelScore(txt)
    }
    else if (txt.includes("竞赛") || txt.includes("码蹄杯") || txt.includes("建模") || txt.includes("外研社") || txt.includes("国才杯") || txt.includes("词达人") || txt.includes("蓝桥杯") || txt.includes("传智杯") || txt.includes("数维杯") || txt.includes("跨文化")) {
      comp += matchLevelScore(txt)
    }
    else if (txt.includes("三下乡") || txt.includes("百千万工程") || txt.includes("实践报告")) {
      practicePrize += matchLevelScore(txt)
    }
    else if (txt.includes("奖学金") || txt.includes("团员") || txt.includes("团干") || txt.includes("骨干") || txt.includes("三好") || txt.includes("学员") || txt.includes("志愿者") || txt.includes("证书") || txt.includes("个人")) {
      honor += matchLevelScore(txt)
    }
  }
  return { comp, innov, honor, practicePrize }
}

function calcActivitiesScore(actList) {
  let partyClass = 0, red = 0, practiceAct = 0, inter = 0, peer = 0

  for (const item of actList) {
    const txt = cleanSafeText(item)
    if (txt.includes("党校") || txt.includes("党课")) {
      partyClass += RULES.perActivity.party
    }
    if (txt.includes("升旗") || txt.includes("植树") || txt.includes("团日") || txt.includes("研学")) {
      red += RULES.perActivity.red
    }
    if (txt.includes("三下乡") || txt.includes("百千万") || txt.includes("电商助农")) {
      practiceAct += RULES.perActivity.practice
    }
    if (txt.includes("留学生") || txt.includes("国际文化") || txt.includes("国际交流")) {
      inter += RULES.perActivity.inter
    }
    if (txt.includes("助班") || txt.includes("欢送会") || txt.includes("行前教育") || txt.includes("录制") || txt.includes("协助") || txt.includes("主持人") || txt.includes("开幕式") || txt.includes("音乐会") || txt.includes("巡查") || txt.includes("讲座") || txt.includes("读书会") || txt.includes("院赛") || txt.includes("工作人员") || txt.includes("医疗")) {
      peer += RULES.perActivity.peer
    }
  }
  return { partyClass, red, practiceAct, inter, peer }
}

// ===================== 云函数主入口 =====================
exports.main = async function (event) {
  const { action } = event
  const termOptions = getTermOptions()
  try {
    // ========== 一次性批量修复旧学期数据（管理后台手动调用） ==========
    if (action === "fixAllTerm") {
      const res = await fixAllTerm()
      return { code: 0, msg: `批量学期修复完成，共更新${res.fixCount}条记录`, data: res }
    }

    // ========== Excel批量导入计算（完全匹配你给出的Excel表头） ==========
    if (action === "importExcelAndCalcScore") {
      const { excelFileID, term } = event
      let globalFallbackTerm = formatTerm(term || "2025-2026下")
      if (!termOptions.includes(globalFallbackTerm)) {
        return { code: -1, msg: "默认学期不合法，请传入标准学期" }
      }
      if (!excelFileID) return { code: -99, msg: "缺少excelFileID" }

      const fileRes = await cloud.downloadFile({ fileID: excelFileID })
      const wb = XLSX.read(fileRes.fileContent, { type: "buffer" })
      const dataList = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]])
      if (!dataList.length) return { code: -1, msg: "表格无有效数据" }

      let successCount = 0
      let failMsgArr = []
      let parsedRecords = []

      for (let i = 0; i < dataList.length; i++) {
        const row = dataList[i]
        const lineNum = i + 2
        try {
          const stuIdText = cleanSafeText(getCellValue(row, ["学号", "studentId"]))
          const studentId = Number(stuIdText)
          const rName = cleanSafeText(getCellValue(row, ["姓名", "realName"]))
          const cName = cleanSafeText(getCellValue(row, ["班级", "className"]))
          if (!rName || isNaN(studentId) || studentId <= 0) continue

          const rawExcelTerm = cleanSafeText(getCellValue(row, ["学期", "term"]))
          let currentTerm = rawExcelTerm ? formatTerm(rawExcelTerm) : globalFallbackTerm
          if (!termOptions.includes(currentTerm)) {
            throw new Error(`学期「${rawExcelTerm}」格式化后「${currentTerm}」不在允许学期列表内`)
          }

          const studyRankStr = getCellValue(row, ["学习成绩排名", "学习排名"])
          const zongRankStr = getCellValue(row, ["综测排名"])
          const postStr = getCellValue(row, ["职位（班级/部门）", "职位"])
          const volStr = getCellValue(row, ["志愿总时长"])
          const actStr = getCellValue(row, ["参与学校、学院的活动（请罗列）", "活动"])
          const awardStr = getCellValue(row, ["获奖情况", "获奖"])

          const isAbs = cleanSafeText(getCellValue(row, ["是否旷课"])) === "是"
          const isFail = cleanSafeText(getCellValue(row, ["是否挂科"])) === "是"
          const isDis = cleanSafeText(getCellValue(row, ["是否违纪"])) === "是"

          const actArr = splitItemList(actStr)
          const awardArr = splitItemList(awardStr)

          const studyRankSc = getRankScore(studyRankStr)
          const zongRankSc = getRankScore(zongRankStr)
          const postSc = getPostScore(postStr)
          const volHours = parseVolText(volStr)

          const awardsScoreObj = getAwardCategoryScores(awardArr)
          const actsScoreObj = calcActivitiesScore(actArr)

          const unexcusedAbsence = isAbs ? 2.0 : 0.0
          const failedCourse = isFail ? 3.0 : 0.0
          const disciplinarySanction = isDis ? 5.0 : 0.0

          const socialWork = postSc
          const academicCompetition = studyRankSc + zongRankSc + awardsScoreObj.comp
          const innovationEntrepreneurship = awardsScoreObj.innov
          const scholarshipHonor = awardsScoreObj.honor

          const partyClassStudy = actsScoreObj.partyClass
          const volunteerService = Math.min(volHours * RULES.volunteer.rate, RULES.volunteer.cap)
          const redHeartActivity = actsScoreObj.red
          const socialPractice = actsScoreObj.practiceAct + awardsScoreObj.practicePrize
          const internationalExchange = actsScoreObj.inter
          const peerMutualAid = actsScoreObj.peer

          const scoreStorageNode = {
            studentId: studentId,
            unexcusedAbsence: Number(unexcusedAbsence.toFixed(1)),
            realName: rName,
            scholarshipHonor: Number(scholarshipHonor.toFixed(1)),
            volunteerService: Number(volunteerService.toFixed(1)),
            disciplinarySanction: Number(disciplinarySanction.toFixed(1)),
            oneVoteVeto: 0.0,
            className: cName,
            redHeartActivity: Number(redHeartActivity.toFixed(1)),
            socialPractice: Number(socialPractice.toFixed(1)),
            inappropriateRemarks: 0.0,
            networkViolation: 0.0,
            socialWork: Number(socialWork.toFixed(1)),
            academicCompetition: Number(academicCompetition.toFixed(1)),
            innovationEntrepreneurship: Number(innovationEntrepreneurship.toFixed(1)),
            partyClassStudy: Number(partyClassStudy.toFixed(1)),
            internationalExchange: Number(internationalExchange.toFixed(1)),
            peerMutualAid: Number(peerMutualAid.toFixed(1)),
            failedCourse: Number(failedCourse.toFixed(1)),
            term: currentTerm,
            createTime: new Date()
          }
          parsedRecords.push(calcScoreItem(scoreStorageNode))
        } catch (singleRowErr) {
          failMsgArr.push(`第${lineNum}行(${row["姓名"] || "未知"}): ${singleRowErr.message}`)
        }
      }

      const BATCH_SIZE = 25
      for (let i = 0; i < parsedRecords.length; i += BATCH_SIZE) {
        const chunk = parsedRecords.slice(i, i + BATCH_SIZE)
        const taskPromises = chunk.map(async (record) => {
          await db.collection("score").where({ studentId: record.studentId, term: record.term }).remove()
          await db.collection("score").add({ data: record })
          successCount++
        })
        await Promise.all(taskPromises)
      }
      return {
        code: 0,
        msg: `导入处理完成：成功 ${successCount} 条${failMsgArr.length ? `，失败 ${failMsgArr.length} 条` : ""}`,
        count: successCount,
        failList: failMsgArr
      }
    }

    // ========== 查询全部积分（分页突破100条，支持学号前四位年份筛选） ==========
    if (action === "getScoreList" || action === "getAllDesc") {
      const { studentIdPrefix } = event
      const countRes = await db.collection("score").count()
      const totalCount = countRes.total
      const MAX_LIMIT = 100
      const chunkTimes = Math.ceil(totalCount / MAX_LIMIT)
      const fetchTasks = []
      for (let i = 0; i < chunkTimes; i++) {
        fetchTasks.push(db.collection("score").orderBy("createTime", "desc").skip(i * MAX_LIMIT).limit(MAX_LIMIT).get())
      }
      const allChunks = await Promise.all(fetchTasks)
      let mergedList = allChunks.reduce((acc, cur) => acc.concat(cur.data), [])

      if (studentIdPrefix && studentIdPrefix.length === 4) {
        const yearNum = Number(studentIdPrefix)
        mergedList = mergedList.filter(item => {
          const sid = Number(item.studentId ?? 0)
          if (sid < 10000000000000) return false
          const stuYear = Math.floor(sid / 100000000)
          return stuYear === yearNum
        })
      }

      mergedList = mergedList.map(row => calcScoreItem(row))
      return { code: 0, data: mergedList, total: mergedList.length }
    }

    // ========== 查询个人学期积分历史 getUserScoreHistory（主键改为studentId） ==========
    if (action === "getUserScoreHistory") {
      const { studentId, term } = event
      const where = {};
      if (!isNaN(Number(studentId)) && Number(studentId) > 0) where.studentId = Number(studentId);
      if (term) {
        const formatQTerm = formatTerm(term)
        if (!termOptions.includes(formatQTerm)) {
          return { code: -1, msg: "筛选学期格式不合法" }
        }
        where.term = formatQTerm;
      }
      const res = await db.collection("score").where(where).get()
      const calcData = res.data.map(row => calcScoreItem(row))
      return { code: 0, data: calcData }
    }

    // ========== 手动新增单条积分（查重使用学号+学期） ==========
    if (action === "addScore") {
      const {
        term, realName, className, studentId,
        socialWork, academicCompetition, innovationEntrepreneurship, scholarshipHonor,
        partyClassStudy, volunteerService, redHeartActivity, socialPractice, internationalExchange, peerMutualAid,
        inappropriateRemarks, failedCourse, unexcusedAbsence, networkViolation, disciplinarySanction, oneVoteVeto
      } = event
      const addData = {
        term,
        realName,
        className,
        studentId: Number(studentId) || 0,
        socialWork: Number(socialWork || 0),
        academicCompetition: Number(academicCompetition || 0),
        innovationEntrepreneurship: Number(innovationEntrepreneurship || 0),
        scholarshipHonor: Number(scholarshipHonor || 0),
        partyClassStudy: Number(partyClassStudy || 0),
        volunteerService: Number(volunteerService || 0),
        redHeartActivity: Number(redHeartActivity || 0),
        socialPractice: Number(socialPractice || 0),
        internationalExchange: Number(internationalExchange || 0),
        peerMutualAid: Number(peerMutualAid || 0),
        inappropriateRemarks: Number(inappropriateRemarks || 0),
        failedCourse: Number(failedCourse || 0),
        unexcusedAbsence: Number(unexcusedAbsence || 0),
        networkViolation: Number(networkViolation || 0),
        disciplinarySanction: Number(disciplinarySanction || 0),
        oneVoteVeto: Number(oneVoteVeto || 0),
        createTime: new Date()
      }
      await db.collection("score").add({ data: addData })
      return { code: 0, msg: "新增成功" }
    }

    // ========== 编辑更新单条积分 updateScore ==========
    if (action === "updateScore") {
      const input = event;
      console.log("【云函数完整接收前端入参】", JSON.parse(JSON.stringify(input)));
    
      // 1、解构名 和 数据库/前端提交key 100%完全一致
      const {
        _id, term, realName, className, studentId,
        socialWork, academicCompetition, innovationEntrepreneurship, scholarshipHonor,
        partyClassStudy, volunteerService, redHeartActivity, socialPractice, internationalExchange, peerMutualAid,
        inappropriateRemarks, failedCourse, unexcusedAbsence, networkViolation, disciplinarySanction, oneVoteVeto
      } = input;
    
      if (!_id) return { code: -1, msg: "缺少记录ID" };
    
      const updateData = {
        term,
        realName,
        className,
        studentId: Number(studentId) || 0,
        socialWork: Number(socialWork || 0),
        academicCompetition: Number(academicCompetition || 0),
        innovationEntrepreneurship: Number(innovationEntrepreneurship || 0),
        scholarshipHonor: Number(scholarshipHonor || 0),
        partyClassStudy: Number(partyClassStudy || 0),
        volunteerService: Number(volunteerService || 0),
        redHeartActivity: Number(redHeartActivity || 0),
        socialPractice: Number(socialPractice || 0),
        internationalExchange: Number(internationalExchange || 0),
        peerMutualAid: Number(peerMutualAid || 0),
        inappropriateRemarks: Number(inappropriateRemarks || 0),
        failedCourse: Number(failedCourse || 0),
        unexcusedAbsence: Number(unexcusedAbsence || 0),
        networkViolation: Number(networkViolation || 0),
        disciplinarySanction: Number(disciplinarySanction || 0),
        oneVoteVeto: Number(oneVoteVeto || 0),
        updateTime: new Date()
      };
      // 2、使用 set + merge:true 强制写入，解决update新旧值相等不更新BUG
      await db.collection("score").doc(_id).set({ data: updateData }, { merge: true });
      return { code: 0, msg: "编辑保存成功" };
    }

    // ========== 删除积分记录 deleteScore ==========
    if (action === "deleteScore") {
      const { _id } = event
      if (!_id) return { code: -1, msg: "缺少记录ID" }
      await db.collection("score").doc(_id).remove()
      return { code: 0, msg: "删除成功" }
    }

    return { code: -1, msg: "未匹配到有效Action事件" }
  } catch (globalErr) {
    console.error("【全局核心异常】", globalErr)
    return { code: -99, msg: "服务器网关异常：" + globalErr.message }
  }
}