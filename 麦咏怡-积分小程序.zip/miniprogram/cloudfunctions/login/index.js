const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()

exports.main = async (event, context) => {
  const { action, name, pwd } = event
  // 区分登录操作
  if (action === "login") {
    const realName = name
    const userRes = await db.collection("user")
      .where({ realName })
      .limit(1)
      .get()
    if (userRes.data.length === 0) {
      return { code: 1, msg: "姓名或密码错误" }
    }
    const user = userRes.data[0]
    if (user.password !== pwd) {
      return { code: 1, msg: "姓名或密码错误" }
    }
    // 统一返回 userInfo 字段，和前端登录代码匹配
    return {
      code: 0,
      msg: "登录成功",
      userInfo: user
    }
  }
  return { code: -99, msg: "无效操作" }
}