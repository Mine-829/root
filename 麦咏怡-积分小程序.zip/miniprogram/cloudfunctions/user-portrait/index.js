// 根据党员姓名汇总画像：积分、材料、支部评价
const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()

exports.main = async (event) => {
  const { userName } = event
  try {
    // 3. 支部画像评价
    const portraitRes = await db.collection('userPortrait')
      .where({ userName })
      .get()
    const portraitInfo = portraitRes.data[0] || {}

    return {
      code: 0,
      data: {
        userName,
        evalContent: portraitInfo.evalContent || '',
        updateBy: portraitInfo.updateBy || '',
        updateTime: portraitInfo.updateTime || ''
      }
    }
  } catch (err) {
    return { code: -99, msg: '读取画像失败', err: err.message }
  }
}