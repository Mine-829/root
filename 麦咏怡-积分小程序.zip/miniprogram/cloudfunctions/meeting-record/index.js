const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()
const coll = db.collection('meeting')

exports.main = async (event) => {
  const { type, _id, title, content, createBy } = event
  try {
    if (type === 'add') {
      // 参数校验，防止空字段入库报错
      if (!title || !content || !createBy) {
        return { code: -1, msg: "参数缺失：标题/内容/创建人不能为空" }
      }
      await coll.add({
        data: {
          title,
          content,
          createBy,
          createTime: db.serverDate()
        }
      })
      return { code: 0, msg: "保存成功" }
    }
    if (type === 'list') {
      const data = await coll.orderBy('createTime', 'desc').get()
      return { code: 0, data: data.data }
    }
    if (type === 'del') {
      await coll.doc(_id).remove()
      return { code: 0, msg: "删除成功" }
    }
    return { code: -1, msg: "无效操作类型" }
  } catch (err) {
    console.error("meeting-record异常：", err)
    return { code: -99, msg: "数据库操作失败", err: err.message }
  }
}