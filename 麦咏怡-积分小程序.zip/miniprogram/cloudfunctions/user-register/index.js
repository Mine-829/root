const cloud = require('wx-server-sdk')
cloud.init({ env: "cloud1-d7g8homtt4ad90b72" })
const db = cloud.database()

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { name, className, studentId } = event

  // 校验：姓名、班级、学号全部必填
  if (!name || !className || !studentId) {
    return { code: -1, msg: "姓名、班级、学号不能为空" }
  }
  // 学号仅允许纯数字
  if (!/^\d+$/.test(studentId)) {
    return { code: -1, msg: "学号必须为纯数字" }
  }
  const trimName = name.trim()
  const trimClass = className.trim()
  const trimStuId = studentId.trim()

  // 1. 查询当前微信openid是否已注册
  const userCheck = await db.collection("user").where({ openid: OPENID }).get()
  if (userCheck.data.length > 0) {
    return {
      code: 0,
      msg: "已注册",
      data: userCheck.data[0]
    }
  }

  // 2. 校验学号是否已被其他微信绑定（唯一学号限制）
  const stuIdCheck = await db.collection("user").where({ studentId: trimStuId }).get()
  if (stuIdCheck.data.length > 0) {
    return { code: -1, msg: "该学号已被其他微信账号注册" }
  }

  // 3. 创建新用户，默认角色改为 member
  const addUserRes = await db.collection("user").add({
    data: {
      openid: OPENID,
      name: trimName,
      className: trimClass,
      studentId: Number(trimStuId), // 学号存数字类型
      role: "member", // 默认普通党员member，管理员后台手动修改为admin
      createTime: new Date()
    }
  })
  const newUserInfo = await db.collection("user").doc(addUserRes._id).get()

  // 4. 批量匹配存量score积分：优先学号精准匹配，其次姓名班级兜底
  await db.collection("score")
    .where({
      studentId: Number(trimStuId),
      userId: db.command.or([db.command.eq(""), db.command.exists(false)])
    })
    .update({
      data: { userId: addUserRes._id }
    })

  // 兜底：无学号的旧数据，用姓名班级匹配（兼容历史数据）
  await db.collection("score")
    .where({
      realName: trimName,
      className: trimClass,
      studentId: db.command.or([db.command.eq(""), db.command.exists(false)]),
      userId: db.command.or([db.command.eq(""), db.command.exists(false)])
    })
    .update({
      data: {
        userId: addUserRes._id,
        studentId: Number(trimStuId) // 同步补全学号
      }
    })

  return {
    code: 0,
    msg: "注册成功，已自动匹配你的全部积分记录",
    userId: addUserRes._id,
    studentId: Number(trimStuId),
    role: "member", // 返回默认角色member
    userInfo: newUserInfo.data
  }
}