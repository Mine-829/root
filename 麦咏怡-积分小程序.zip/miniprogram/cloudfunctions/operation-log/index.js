const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = function (event, context) {
  var type = "";
  var adminName = "";
  var operateContent = "";
  if (event) {
    type = event.type || "";
    adminName = event.adminName || "";
    operateContent = event.operateContent || "";
  }

  return new Promise(function (resolve, reject) {
    try {
      // 1. 新增操作日志（会议增删调用）
      if (type === "add") {
        if (!adminName || !operateContent) {
          resolve({ code: -2, msg: "参数缺失" });
          return;
        }
        var openId = "";
        if (event && event.userInfo && event.userInfo.openId) {
          openId = event.userInfo.openId;
        }
        db.collection("operation_log").add({
          data: {
            adminName: adminName,
            operateContent: operateContent,
            operateTime: db.serverDate(),
            adminOpenId: openId
          }
        }).then(function () {
          resolve({ code: 0, msg: "日志记录成功" });
        }).catch(function (err) {
          console.error("新增日志异常", err);
          resolve({ code: -1, msg: "操作失败", errMsg: err.message });
        })
        return;
      }

      // 2. 查询全部操作日志（admin-log页面读取）
      if (type === "list") {
        db.collection("operation_log")
          .orderBy("operateTime", "desc")
          .get()
          .then(function (res) {
            resolve({ code: 0, data: res.data });
          })
          .catch(function (err) {
            console.error("查询日志异常", err);
            resolve({ code: -1, msg: "操作失败", errMsg: err.message });
          })
        return;
      }

      // 3. 一键清空所有操作日志（新增）
      if (type === "clearAll") {
        db.collection("operation_log")
          .where({
            // 匹配全部文档
            _id: _.neq("")
          })
          .remove()
          .then(function () {
            resolve({ code: 0, msg: "全部日志已清空" });
          })
          .catch(function (err) {
            console.error("清空日志异常", err);
            resolve({ code: -1, msg: "清空失败", errMsg: err.message });
          })
        return;
      }

      // 无效类型
      resolve({ code: -99, msg: "无效操作类型" });
    } catch (err) {
      console.error("日志云函数外层异常", err);
      resolve({ code: -1, msg: "操作失败", errMsg: err.message });
    }
  })
}