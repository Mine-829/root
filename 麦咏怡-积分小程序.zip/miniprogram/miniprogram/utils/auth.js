// 管理员权限守卫
export function adminGuard() {
  const userInfo = wx.getStorageSync("userInfo")
  if (!userInfo || userInfo.role !== "admin") {
    wx.showToast({
      title: "仅管理员可访问",
      icon: "none",
      duration: 1200
    })
    setTimeout(() => {
      wx.reLaunch({
        url: "/pages/login/login"
      })
    }, 1200)
    return false
  }
  return true
}

// 原有adminAuth（兼容其他页面）
export function adminAuth() {
  const userInfo = wx.getStorageSync("userInfo")
  if (!userInfo || userInfo.role !== "admin") {
    wx.showToast({
      title: "无管理员权限",
      icon: "none",
      duration: 1200
    })
    setTimeout(() => {
      wx.reLaunch({
        url: "/pages/login/login"
      })
    }, 1200)
    return false
  }
  return true
}