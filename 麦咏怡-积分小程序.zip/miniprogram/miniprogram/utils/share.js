function getShareInfo() {
  return {
    title: "国际交流学院党支部管理系统",
    path: "/pages/login/login",
    desc: "党员积分管理系统"
  }
}
function getTimeLineShare() {
  return {
    title: "党支部管理系统"
  }
}
module.exports = { getShareInfo, getTimeLineShare }