Page({
  data: {
    studentId: "",
    password: ""
  },

  inputStudentId(e) {
    let val = e.detail.value
    val = val.replace(/[^\d]/g, '')
    this.setData({ studentId: val })
  },

  inputPassword(e) {
    this.setData({ password: e.detail.value })
  },

  async handleLogin() {
    const { studentId, password } = this.data
    if (!studentId || !password) {
      return wx.showToast({ title: "学号密码不能为空", icon: "none" })
    }
    if (isNaN(Number(studentId))) {
      return wx.showToast({ title: "学号只能是数字", icon: "none" })
    }

    // 控制台打印当前输入学号
    console.log("当前登录输入学号：", studentId)

    wx.showLoading({ title: "登录校验中..." })
    try {
      const res = await wx.cloud.callFunction({
        name: "userCrud",
        data: {
          action: "login",
          studentId,
          pwd: password
        }
      })
      wx.hideLoading()

      if (res.result.code === 0) {
        const user = res.result.userInfo
        console.log("登录成功，用户完整信息：", user)
        console.log("登录用户学号 studentId：", user.studentId)
        console.log("登录用户角色 role：", user.role)

        // 缓存用户全套信息，供首页读取学号、角色
        wx.setStorageSync("userInfo", user)
        wx.setStorageSync("userId", user._id)
        wx.setStorageSync("studentId", user.studentId)
        wx.setStorageSync("role", user.role)

        wx.showToast({ title: "登录成功" })
        setTimeout(() => {
          if (user.role === "admin") {
            wx.redirectTo({ url: "/pages/admin/admin" })
          } else {
            wx.redirectTo({ url: "/pages/user/user" })
          }
        }, 150)
      } else {
        wx.showToast({ title: res.result.msg, icon: "none" })
      }
    } catch (err){
      wx.hideLoading()
      wx.showToast({ title: "网络异常，登录失败", icon: "none" })
      console.error("登录接口异常：", err)
    }
  },

  goRegister() {
    wx.navigateTo({ url: "/pages/register/register" })
  }
})