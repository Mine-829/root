Page({
  data: {
    studentId: "",
    realName: "",
    className: "",
    password: ""
  },

  inputStudentId(e) {
    let val = e.detail.value
    val = val.replace(/[^\d]/g, '')
    this.setData({ studentId: val })
  },
  inputRealName(e) {
    this.setData({ realName: e.detail.value })
  },
  inputClassName(e) {
    this.setData({ className: e.detail.value })
  },
  inputPassword(e) {
    this.setData({ password: e.detail.value })
  },

  async handleRegister() {
    const { studentId, realName, className, password } = this.data
    if (!studentId || !realName || !className || !password) {
      return wx.showToast({ title: "学号、姓名、班级、密码不能为空", icon: "none" })
    }
    if (isNaN(Number(studentId))) {
      return wx.showToast({ title: "学号只能是数字", icon: "none" })
    }

    wx.showLoading({ title: "注册提交中..." })
    try {
      const cloudRes = await wx.cloud.callFunction({
        name: "userCrud",
        data: {
          action: "register",
          studentId,
          realName,
          className,
          pwd: password
        }
      })
      wx.hideLoading()
      const res = cloudRes.result
      if (res.code === 0) {
        wx.showToast({ title: "注册成功" })
        setTimeout(() => wx.navigateTo({ url: "/pages/login/login" }), 1200)
      } else {
        wx.showToast({ title: res.msg || "注册失败", icon: "none" })
      }
    } catch (err) {
      wx.hideLoading()
      console.error("注册异常：", err)
      wx.showToast({ title: "网络异常，注册失败", icon: "none" })
    }
  },

  goLogin() {
    wx.navigateTo({ url: "/pages/login/login" })
  },
  addLog(content) {
    const admin = wx.getStorageSync("userInfo")
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "add",
        adminName: admin?.realName || "游客注册",
        operateContent: content
      }
    })
  },
})