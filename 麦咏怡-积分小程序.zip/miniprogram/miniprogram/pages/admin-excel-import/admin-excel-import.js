Page({
  data: {
    selectedFileId: "",
    selectedFileName: "",
    result: null,
    scoreList: []
  },

  // 选择Excel文件
  chooseExcel() {
    const that = this
    console.log("【开始选择Excel文件】")
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      extension: ['xlsx', 'xls'],
      success: function (res) {
        console.log("【选择文件成功，原始返回】", res)
        const file = res.tempFiles[0]
        console.log("【选中文件信息】路径:", file.path, "文件名:", file.name)
        that.setData({
          selectedFileId: file.path,
          selectedFileName: file.name
        }, function () {
          console.log("【setData完成，当前文件变量】", that.data.selectedFileId, that.data.selectedFileName)
        })
      },
      fail: function (err) {
        console.error("【选择Excel文件失败】", err)
        wx.showToast({ title: "未选择文件", icon: "none" })
      }
    })
  },

  // 上传导入
  async startImportAndCalc() {
    const that = this
    console.log("【触发批量导入Excel】")
    if (!that.data.selectedFileId) {
      console.log("【校验失败：未选择文件】")
      wx.showToast({ title: "请先选择Excel文件", icon: "none" })
      return
    }
    console.log("【待上传文件路径】", that.data.selectedFileId)
    wx.showLoading({ title: "处理中..." })
    try {
      console.log("【开始上传文件到云存储】")
      const uploadRes = await wx.cloud.uploadFile({
        cloudPath: `excel/${Date.now()}.xlsx`,
        filePath: that.data.selectedFileId
      })
      console.log("【文件上传完成，fileID】", uploadRes.fileID)

      console.log("【调用云函数 importExcelAndCalcScore】")
      const callRes = await wx.cloud.callFunction({
        name: "crud-score",
        data: {
          action: "importExcelAndCalcScore",
          excelFileID: uploadRes.fileID
        }
      })
      console.log("【云函数导入完整返回】", callRes)
      wx.hideLoading()
      that.setData({ result: callRes.result }, function () {
        console.log("【导入结果赋值完成】", that.data.result)
      })
      wx.showToast({ title: callRes.result.msg, icon: "success" })
      that.getScoreList()
      // 导入成功写入操作日志
      this.addLog(`批量导入Excel积分文件：${that.data.selectedFileName}`)
      console.log("【导入操作日志已发起】")
    } catch (err) {
      wx.hideLoading()
      console.error("【Excel导入整体捕获异常】", err)
      wx.showToast({ title: "导入失败", icon: "none" })
    }
  },

  // 获取积分列表
  getScoreList() {
    const that = this
    console.log("【加载全部积分列表】")
    wx.cloud.callFunction({
      name: "crud-score",
      data: { action: "getScoreList" },
      success: function (res) {
        console.log("【getScoreList云函数原始返回】", res)
        let list = res.result?.data ?? []
        console.log("【原始积分数据长度】", list.length)
        list.sort((a, b) => b.totalScore - a.totalScore)
        console.log("【排序后第一条数据示例】", list[0])
        that.setData({ scoreList: list }, function () {
          console.log("【积分列表赋值完成，列表长度】", that.data.scoreList.length)
        })
      },
      fail: function (err) {
        console.error("【获取积分列表接口失败】", err)
        that.setData({ scoreList: [] })
      }
    })
  },

  onLoad() {
    console.log("【Excel导入页面onLoad初始化】")
    this.getScoreList()
  },

  // 统一操作日志写入方法（所有管理员页面通用）
  addLog(content) {
    const admin = wx.getStorageSync("userInfo")
    console.log("【写入操作日志，内容】", content, "操作管理员：", admin?.realName)
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "add",
        adminName: admin.realName,
        operateContent: content
      },
      success: function (res) {
        console.log("【操作日志写入成功返回】", res)
      },
      fail: function (err) {
        console.error("【操作日志写入失败】", err)
      }
    })
  },
})