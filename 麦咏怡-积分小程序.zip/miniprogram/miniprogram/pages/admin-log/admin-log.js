var authUtil = require("../../utils/auth");

Page({
  data: {
    logList: [],
    hideLogFlag: false
  },
  onShow: function () {
    if (!authUtil.adminAuth()) {
      return;
    }
    var hideFlag = wx.getStorageSync("hideOperationLogFlag") || false;
    this.setData({
      hideLogFlag: hideFlag
    });
    if (!hideFlag) {
      this.getLogList();
    }
  },
  // 加载日志列表
  getLogList: function () {
    var that = this;
    wx.showLoading({
      title: "加载日志..."
    });
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "list"
      },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          var list = res.result.data || [];
          that.setData({
            logList: list
          });
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: "日志加载失败",
          icon: "none"
        });
      }
    });
  },
  // 本地隐藏（不删数据库，仅前端屏蔽）
  clearLogLocal: function () {
    var that = this;
    wx.showModal({
      title: "本地隐藏日志",
      content: "仅当前设备隐藏，云端日志保留，刷新不再加载",
      success: function (res) {
        if (!res.confirm) {
          return;
        }
        wx.setStorageSync("hideOperationLogFlag", true);
        that.setData({
          hideLogFlag: true,
          logList: []
        });
        wx.showToast({
          title: "已本地隐藏"
        });
      }
    });
  },
  // 云端一键清空（调用云函数删除全部数据库记录）
  clearAllLogCloud: function () {
    var that = this;
    wx.showModal({
      title: "危险操作",
      content: "确定永久删除云端全部操作日志？删除后无法恢复！",
      success: function (res) {
        if (!res.confirm) {
          return;
        }
        wx.showLoading({
          title: "清空中..."
        });
        wx.cloud.callFunction({
          name: "operation-log",
          data: {
            type: "clearAll"
          },
          success: function (res) {
            wx.hideLoading();
            if (res.result.code === 0) {
              wx.showToast({
                title: "全部日志已清空"
              });
              that.setData({
                logList: []
              });
            } else {
              wx.showToast({
                title: res.result.msg,
                icon: "none"
              });
            }
          },
          fail: function () {
            wx.hideLoading();
            wx.showToast({
              title: "清空请求失败",
              icon: "none"
            });
          }
        });
      }
    });
  },
  // 恢复本地隐藏
  recoverLog: function () {
    var that = this;
    wx.removeStorageSync("hideOperationLogFlag");
    that.setData({
      hideLogFlag: false
    });
    that.getLogList();
    wx.showToast({
      title: "已恢复日志列表"
    });
  },
  // ES5 时间格式化
  formatTime: function (timestamp) {
    if (!timestamp) {
      return "";
    }
    var d = new Date(timestamp);
    var year = d.getFullYear();
    var month = d.getMonth() + 1;
    var day = d.getDate();
    var hour = d.getHours();
    var minute = d.getMinutes();
    function addZero(num) {
      return num < 10 ? "0" + num : num;
    }
    return year + "-" + addZero(month) + "-" + addZero(day) + " " + addZero(hour) + ":" + addZero(minute);
  }
})