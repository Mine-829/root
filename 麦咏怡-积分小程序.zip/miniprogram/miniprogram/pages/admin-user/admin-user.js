Page({
  data: {
    originUserList: [],
    userList: [],
    showAdd: false,
    showEdit: false,
    addStudentId: "",
    addName: "",
    addClass: "",
    addPwd: "",
    editDocId: "",
    editStudentId: "",
    editRealName: "",
    editClassName: "",
    editPwd: "",
    yearPickerIndex: 0,
    yearRange: []
  },

  onLoad: function () {
    // 先缓存登录用户，全程复用，避免多次读取storage异常
    this.cacheAdmin = wx.getStorageSync("loginUser");
    this.initYearRange();
    this.checkAdminAuth();
    this.getUserList();
  },

  onUnload: function () {
    this.setData({
      originUserList: [],
      userList: []
    });
    this.cacheAdmin = null;
  },

  initYearRange: function(){
    var now = new Date();
    var currentYear = now.getFullYear();
    var arr = ["全部入学年份"];
    var startYear = 2022;
    for(var y = startYear; y <= currentYear + 4; y++){
      arr.push(String(y));
    }
    this.setData({
      yearRange: arr
    });
  },

  checkAdminAuth: function () {
    var user = this.cacheAdmin;
    if (!user || user.role !== "admin") {
      wx.redirectTo({ url: "/pages/login/login" });
      wx.showToast({ title: "无管理员权限", icon: "none" });
    }
  },

  getUserList: function () {
    var that = this;
    wx.showLoading({ title: "加载用户列表" });
    wx.cloud.callFunction({
      name: "userCrud",
      data: { action: "getUserList" },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          that.setData({ originUserList: res.result.data }, function(){
            that.filterUserByYear();
          });
        } else {
          wx.showToast({ title: res.result.msg, icon: "none" });
        }
      }.bind(that),
      fail: function (err) {
        wx.hideLoading();
        wx.showToast({ title: "用户列表加载失败", icon: "none" });
      }.bind(that)
    });
  },

  filterUserByYear: function () {
    var allData = this.data.originUserList;
    var selectYear = this.data.yearRange[this.data.yearPickerIndex];
    var filterArr = [];
    if (selectYear === "全部入学年份") {
      filterArr = allData;
    } else {
      for(var i = 0; i < allData.length; i++){
        var item = allData[i];
        var stuIdStr = String(item.studentId || "");
        var stuYear = stuIdStr.slice(0,4);
        if(stuYear === selectYear){
          filterArr.push(item);
        }
      }
    }
    this.setData({ userList: filterArr });
  },

  onYearPickerChange: function (e) {
    var idx = e.detail.value;
    this.setData({ yearPickerIndex: idx }, function(){
      this.filterUserByYear();
    });
  },

  openAddPopup: function () {
    this.setData({
      showAdd: true,
      addStudentId: "",
      addName: "",
      addClass: "",
      addPwd: ""
    });
  },
  closePopup: function () {
    this.setData({ showAdd: false });
  },

  openEditPopup: function (e) {
    var dataset = e.currentTarget.dataset;
    this.setData({
      showEdit: true,
      editDocId: dataset.docId || "",
      editStudentId: String(dataset.studentId || ""),
      editRealName: dataset.realName || "",
      editClassName: dataset.className || "",
      editPwd: ""
    });
  },
  closeEditPopup: function () {
    this.setData({ showEdit: false });
  },

  noop: function () {},

  inputStudentId: function (e) { this.setData({ addStudentId: e.detail.value }); },
  inputName: function (e) { this.setData({ addName: e.detail.value }); },
  inputClass: function (e) { this.setData({ addClass: e.detail.value }); },
  inputPwd: function (e) { this.setData({ addPwd: e.detail.value }); },

  inputEditName: function (e) { this.setData({ editRealName: e.detail.value }); },
  inputEditClass: function (e) { this.setData({ editClassName: e.detail.value }); },
  inputEditPwd: function (e) { this.setData({ editPwd: e.detail.value }); },

  submitAdd: function () {
    var that = this;
    var sid = this.data.addStudentId;
    var name = this.data.addName;
    var className = this.data.addClass;
    var pwd = this.data.addPwd;

    if (!sid || !sid.trim()) {
      wx.showToast({ title: "请填写学号", icon: "none" });
      return;
    }
    if (!name || !name.trim()) {
      wx.showToast({ title: "请填写姓名", icon: "none" });
      return;
    }
    if (!className || !className.trim()) {
      wx.showToast({ title: "请填写班级", icon: "none" });
      return;
    }
    if (!pwd || !pwd.trim()) {
      wx.showToast({ title: "请填写密码", icon: "none" });
      return;
    }

    wx.showLoading({ title: "新增用户中" });
    wx.cloud.callFunction({
      name: "userCrud",
      data: {
        action: "register",
        studentId: sid,
        realName: name.trim(),
        className: className.trim(),
        pwd: pwd
      },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          wx.showToast({ title: "新增成功" });
          that.closePopup();
          that.getUserList();
          var logStr = "管理员新增用户：学号" + String(sid) + "，姓名" + String(name);
          that.addLog(logStr);
        } else {
          wx.showToast({ title: res.result.msg, icon: "none" });
        }
      }.bind(that),
      fail: function () {
        wx.hideLoading();
        wx.showToast({ title: "新增请求失败", icon: "none" });
      }.bind(that)
    });
  },

  submitEdit: function () {
    var that = this;
    var docId = this.data.editDocId;
    var realName = this.data.editRealName;
    var className = this.data.editClassName;
    var newPwd = this.data.editPwd;

    if (!realName || !realName.trim()) {
      wx.showToast({ title: "请填写姓名", icon: "none" });
      return;
    }
    if (!className || !className.trim()) {
      wx.showToast({ title: "请填写班级", icon: "none" });
      return;
    }

    wx.showLoading({ title: "保存修改" });
    var updateData = {};
    updateData.realName = realName.trim();
    updateData.className = className.trim();
    if (newPwd && newPwd.trim()) {
      updateData.password = newPwd;
    }

    wx.cloud.callFunction({
      name: "userCrud",
      data: {
        action: "editUser",
        _id: docId,
        update: updateData
      },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          wx.showToast({ title: "修改成功" });
          that.closeEditPopup();
          that.getUserList();
          var logStr = "管理员编辑用户，文档ID：" + String(docId);
          that.addLog(logStr);
        } else {
          wx.showToast({ title: res.result.msg, icon: "none" });
        }
      }.bind(that),
      fail: function () {
        wx.hideLoading();
        wx.showToast({ title: "修改请求失败", icon: "none" });
      }.bind(that)
    });
  },

  delUser: function (e) {
    var that = this;
    var docId = e.currentTarget.dataset.id || "";
    var userName = e.currentTarget.dataset.name || "";
    wx.showModal({
      title: "确认删除",
      content: "删除后不可恢复，确定吗？",
      success: function (res) {
        if (!res.confirm) return;
        wx.showLoading({ title: "删除中" });
        wx.cloud.callFunction({
          name: "userCrud",
          data: {
            action: "delUser",
            _id: docId
          },
          success: function (ret) {
            wx.hideLoading();
            if (ret.result.code === 0) {
              wx.showToast({ title: "已删除" });
              that.getUserList();
              var logStr = "管理员删除用户：文档ID " + String(docId) + "，姓名 " + String(userName);
              that.addLog(logStr);
            } else {
              wx.showToast({ title: ret.result.msg, icon: "none" });
            }
          }.bind(that),
          fail: function () {
            wx.hideLoading();
            wx.showToast({ title: "删除请求失败", icon: "none" });
          }.bind(that)
        });
      }.bind(that)
    });
  },

  changeRole: function (e) {
    var that = this;
    // 修复NaN崩溃：先转字符串再数字兜底
    var rawSid = e.currentTarget.dataset.studentId || "0";
    var targetStudentId = Number(rawSid);
    var oldRole = e.currentTarget.dataset.role || "";
    var newRole = oldRole === "admin" ? "member" : "admin";
    var adminName = "未知管理员";
    if(this.cacheAdmin && this.cacheAdmin.realName){
      adminName = this.cacheAdmin.realName;
    }
    var displayNewRole = "";
    if(newRole === "admin"){
      displayNewRole = "管理员";
    }else{
      displayNewRole = "普通党员";
    }
    var modalContent = "确认将该用户权限改为：" + displayNewRole + "？";
    wx.showModal({
      title: "确认修改用户权限",
      content: modalContent,
      success: function (modalRes) {
        if (!modalRes.confirm) return;
        wx.showLoading({ title: "修改权限中" });
        wx.cloud.callFunction({
          name: "userCrud",
          data: {
            action: "admin-user",
            studentId: targetStudentId,
            newRole: newRole,
            operateAdmin: adminName
          },
          success: function (ret) {
            wx.hideLoading();
            if (ret.result.code === 0) {
              wx.showToast({ title: "权限修改成功" });
              that.getUserList();
              var logStr = "管理员修改用户权限：学号" + String(targetStudentId) + "，旧角色" + String(oldRole) + "，新角色" + String(newRole);
              that.addLog(logStr);
            } else {
              wx.showToast({ title: ret.result.msg, icon: "none" });
            }
          }.bind(that),
          fail: function () {
            wx.hideLoading();
            wx.showToast({ title: "权限修改请求失败", icon: "none" });
          }.bind(that)
        });
      }.bind(that)
    });
  },

  addLog: function (content) {
    var that = this;
    var realName = "未知管理员";
    if(this.cacheAdmin && this.cacheAdmin.realName){
      realName = this.cacheAdmin.realName;
    }
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "add",
        adminName: realName,
        operateContent: content
      },
      success: function(){}.bind(that),
      fail: function() {}.bind(that)
    });
  }
})