Page({
  data: {
    scoreList: [],

    // 学期筛选
    filterTermIndex: 0,
    filterTerm: "全部学期",
    filterTermOptions: ["全部学期"],

    yearStart: 2025,
    termOptions: [],
    addTermIndex: 0,
    editTermIndex: 0,
    addTerm: "",
    editTerm: "",

    // 新增弹窗补充学号
    showAdd: false,
    addStudentId: "",
    addRealName: "",
    addClass: "",
    addSocialWork: 0,
    addSubjectComp: 0,
    addInnovateBiz: 0,
    addScholarHonor: 0,
    addPartyClass: 0,
    addVolunteer: 0,
    addRedHeart: 0,
    addSocialPractice: 0,
    addInterExchange: 0,
    addPeerHelp: 0,
    addWrongSpeech: 0,
    addFailCourse: 0,
    addAbsent: 0,
    addNetViolate: 0,
    addDisciplinePunish: 0,
    addOneVoteVeto: 0,

    showEdit: false,
    editId: "",
    editRealName: "",
    editClass: "",
    editStudentId: 0,
    editSocialWork: 0,
    editSubjectComp: 0,
    editInnovateBiz: 0,
    editScholarHonor: 0,
    editPartyClass: 0,
    editVolunteer: 0,
    editRedHeart: 0,
    editSocialPractice: 0,
    editInterExchange: 0,
    editPeerHelp: 0,
    editWrongSpeech: 0,
    editFailCourse: 0,
    editAbsent: 0,
    editNetViolate: 0,
    editDisciplinePunish: 0,
    editOneVoteVeto: 0
  },

  onLoad: function () {
    this.buildTermList();
    this.getAllScore();
  },

  buildTermList: function () {
    var list = [];
    var filterList = ["全部学期"];
    var start = this.data.yearStart;
    var currentYear = new Date().getFullYear();
    var endYear = currentYear + 5;

    for (var y = start; y < endYear; y++) {
      var yearStr = y + "-" + (y + 1);
      var up = yearStr + "上";
      var down = yearStr + "下";
      list.push(up);
      list.push(down);
      filterList.push(up);
      filterList.push(down);
    }

    this.setData({
      termOptions: list,
      filterTermOptions: filterList,
      addTerm: list[0],
      editTerm: list[0]
    });
  },

  changeFilterTerm: function (e) {
    var idx = e.detail.value;
    var val = this.data.filterTermOptions[idx];
    this.setData({
      filterTermIndex: idx,
      filterTerm: val
    });
    this.getAllScore();
  },

  getAllScore: function () {
    var that = this;
    wx.showLoading({ title: "加载中" });
    wx.cloud.callFunction({
      name: "crud-score",
      data: { action: "getScoreList" },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          var rawData = res.result.data;
          var filterArr = [];
          var filterTerm = that.data.filterTerm;
          for (var i = 0; i < rawData.length; i++) {
            var item = rawData[i];
            if (filterTerm === "全部学期" || item.term === filterTerm) {
              filterArr.push(item);
            }
          }

          var calcList = [];
          for (var m = 0; m < filterArr.length; m++) {
            var item = filterArr[m];
            var studyRaw = Number(item.socialWork || 0) + Number(item.academicCompetition || 0) + Number(item.innovationEntrepreneurship || 0) + Number(item.scholarshipHonor || 0);
            var studyAbility = studyRaw > 40 ? 40 : studyRaw;

            var partyRaw = Number(item.partyClassStudy || 0) + Number(item.volunteerService || 0) + Number(item.redHeartActivity || 0) + Number(item.socialPractice || 0) + Number(item.internationalExchange || 0) + Number(item.peerMutualAid || 0);
            var partyGrow = partyRaw > 60 ? 60 : partyRaw;

            var deductScore = Number(item.inappropriateRemarks || 0) + Number(item.failedCourse || 0) + Number(item.unexcusedAbsence || 0) + Number(item.networkViolation || 0) + Number(item.disciplinarySanction || 0) + Number(item.oneVoteVeto || 0);
            var total = studyAbility + partyGrow - deductScore;
            if (total < 0) total = 0;

            var newItem = {};
            for (var key in item) {
              newItem[key] = item[key];
            }
            newItem.studyAbility = studyAbility;
            newItem.partyGrow = partyGrow;
            newItem.deductScore = deductScore;
            newItem.total = total;
            calcList.push(newItem);
          }

          // 降序排序
          for (var a = 0; a < calcList.length - 1; a++) {
            for (var b = a + 1; b < calcList.length; b++) {
              if (calcList[a].total < calcList[b].total) {
                var temp = calcList[a];
                calcList[a] = calcList[b];
                calcList[b] = temp;
              }
            }
          }
          that.setData({ scoreList: calcList });
        } else {
          wx.showToast({ title: res.result.msg, icon: "none" });
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({ title: "加载失败", icon: "none" });
      }
    });
  },

  changeAddTerm: function (e) {
    var idx = e.detail.value;
    this.setData({
      addTermIndex: idx,
      addTerm: this.data.termOptions[idx]
    });
  },

  changeEditTerm: function (e) {
    var idx = e.detail.value;
    this.setData({
      editTermIndex: idx,
      editTerm: this.data.termOptions[idx]
    });
  },

  inputNumberChange: function (e) {
    var key = e.currentTarget.dataset.key;
    var mode = e.currentTarget.dataset.mode;
    var val = e.detail.value.trim();
    var reg = /^\d*\.?\d*$/;
    if (!reg.test(val)) {
      wx.showToast({ title: "仅可输入数字", icon: "none" });
      return;
    }
    var num = Number(val) || 0;
    var data = {};
    if (mode === "edit") {
      data["edit" + key] = num;
    } else {
      data["add" + key] = num;
    }
    this.setData(data);
  },

  inputTextChange: function (e) {
    var key = e.currentTarget.dataset.key;
    var mode = e.currentTarget.dataset.mode;
    var val = e.detail.value;
    var data = {};
    if (mode === "edit") {
      data["edit" + key] = val;
    } else {
      data["add" + key] = val;
    }
    this.setData(data);
  },

  openAdd: function () {
    this.setData({
      showAdd: true,
      addStudentId: "",
      addRealName: "",
      addClass: "",
      addTermIndex: 0,
      addTerm: this.data.termOptions[0],
      addSocialWork: 0,
      addSubjectComp: 0,
      addInnovateBiz: 0,
      addScholarHonor: 0,
      addPartyClass: 0,
      addVolunteer: 0,
      addRedHeart: 0,
      addSocialPractice: 0,
      addInterExchange: 0,
      addPeerHelp: 0,
      addWrongSpeech: 0,
      addFailCourse: 0,
      addAbsent: 0,
      addNetViolate: 0,
      addDisciplinePunish: 0,
      addOneVoteVeto: 0
    });
  },

  closeAdd: function () {
    this.setData({ showAdd: false });
  },

  openEdit: function (e) {
    var item = e.currentTarget.dataset.item;
    var termIdx = -1;
    for (var t = 0; t < this.data.termOptions.length; t++) {
      if (this.data.termOptions[t] === item.term) {
        termIdx = t;
        break;
      }
    }
    if (termIdx === -1) termIdx = 0;
    this.setData({
      showEdit: true,
      editId: item._id,
      editTerm: item.term,
      editTermIndex: termIdx,
      editRealName: item.realName,
      editClass: item.className,
      editStudentId: Number(item.studentId || 0),
      editSocialWork: item.socialWork || 0,
      editSubjectComp: item.academicCompetition || 0,
      editInnovateBiz: item.innovationEntrepreneurship || 0,
      editScholarHonor: item.scholarshipHonor || 0,
      editPartyClass: item.partyClassStudy || 0,
      editVolunteer: item.volunteerService || 0,
      editRedHeart: item.redHeartActivity || 0,
      editSocialPractice: item.socialPractice || 0,
      editInterExchange: item.internationalExchange || 0,
      editPeerHelp: item.peerMutualAid || 0,
      editWrongSpeech: item.inappropriateRemarks || 0,
      editFailCourse: item.failedCourse || 0,
      editAbsent: item.unexcusedAbsence || 0,
      editNetViolate: item.networkViolation || 0,
      editDisciplinePunish: item.disciplinarySanction || 0,
      editOneVoteVeto: item.oneVoteVeto || 0
    });
  },

  closeEdit: function () {
    this.setData({ showEdit: false });
  },

  submitAdd: function () {
    var addRealName = this.data.addRealName;
    var addClass = this.data.addClass;
    var addTerm = this.data.addTerm;
    var addStudentId = this.data.addStudentId;
    if (!addRealName.trim()) {
      wx.showToast({ title: "请填写姓名", icon: "none" });
      return;
    }
    if (!addClass.trim()) {
      wx.showToast({ title: "请填写班级", icon: "none" });
      return;
    }
    if (!addStudentId.trim()) {
      wx.showToast({ title: "请填写学号", icon: "none" });
      return;
    }
    wx.showLoading({ title: "提交中" });
    wx.cloud.callFunction({
      name: "crud-score",
      data: {
        action: "addScore",
        term: addTerm,
        studentId: Number(addStudentId),
        realName: addRealName.trim(),
        className: addClass.trim(),
        socialWork: Number(this.data.addSocialWork),
        academicCompetition: Number(this.data.addSubjectComp),
        innovationEntrepreneurship: Number(this.data.addInnovateBiz),
        scholarshipHonor: Number(this.data.addScholarHonor),
        partyClassStudy: Number(this.data.addPartyClass),
        volunteerService: Number(this.data.addVolunteer),
        redHeartActivity: Number(this.data.addRedHeart),
        socialPractice: Number(this.data.addSocialPractice),
        internationalExchange: Number(this.data.addInterExchange),
        peerMutualAid: Number(this.data.addPeerHelp),
        inappropriateRemarks: Number(this.data.addWrongSpeech),
        failedCourse: Number(this.data.addFailCourse),
        unexcusedAbsence: Number(this.data.addAbsent),
        networkViolation: Number(this.data.addNetViolate),
        disciplinarySanction: Number(this.data.addDisciplinePunish),
        oneVoteVeto: Number(this.data.addOneVoteVeto)
      }, // 补逗号
      success: function () {
        wx.hideLoading();
        wx.showToast({ title: "新增成功" });
        var content = "新增党员积分：" + addRealName + "（" + addTerm + "）学号：" + addStudentId;
        this.addLog(content);
        this.setData({ showAdd: false });
        this.getAllScore();
      }.bind(this),
      fail: function () {
        wx.hideLoading();
        wx.showToast({ title: "提交失败", icon: "none" });
      }
    });
  },

  saveEdit: function () {
    var editId = this.data.editId;
    var editRealName = this.data.editRealName;
    var editClass = this.data.editClass;
    var editTerm = this.data.editTerm;
    var editStudentId = this.data.editStudentId;
    if (!editRealName.trim()) {
      wx.showToast({ title: "请填写姓名", icon: "none" });
      return;
    }
    if (!editClass.trim()) {
      wx.showToast({ title: "请填写班级", icon: "none" });
      return;
    }
    wx.showLoading({ title: "保存中" });
  
    // ========== 打印放在这里，函数内this有效 ==========
    console.log("提交积分字段", {
      socialWork: Number(this.data.editSocialWork || 0),
      academicCompetition: Number(this.data.editSubjectComp || 0),
      innovationEntrepreneurship: Number(this.data.editInnovateBiz || 0),
      scholarshipHonor: Number(this.data.editScholarHonor || 0),
      partyClassStudy: Number(this.data.editPartyClass || 0),
      volunteerService: Number(this.data.editVolunteer || 0),
      redHeartActivity: Number(this.data.editRedHeart || 0),
      socialPractice: Number(this.data.editSocialPractice || 0),
      internationalExchange: Number(this.data.editInterExchange || 0),
      peerMutualAid: Number(this.data.editPeerHelp || 0),
      inappropriateRemarks: Number(this.data.editWrongSpeech || 0),
      failedCourse: Number(this.data.editFailCourse || 0),
      unexcusedAbsence: Number(this.data.editAbsent || 0),
      networkViolation: Number(this.data.editNetViolate || 0),
      disciplinarySanction: Number(this.data.editDisciplinePunish || 0),
      oneVoteVeto: Number(this.data.editOneVoteVeto || 0)
    });
    // ==============================================
  
    wx.cloud.callFunction({
      name: "crud-score",
      data: {
        action: "updateScore",
        _id: editId,
        studentId: Number(editStudentId || 0),
        term: editTerm,
        realName: editRealName.trim(),
        className: editClass.trim(),
        socialWork: Number(this.data.editSocialWork || 0),
        academicCompetition: Number(this.data.editSubjectComp || 0),
        innovationEntrepreneurship: Number(this.data.editInnovateBiz || 0),
        scholarshipHonor: Number(this.data.editScholarHonor || 0),
        partyClassStudy: Number(this.data.editPartyClass || 0),
        volunteerService: Number(this.data.editVolunteer || 0),
        redHeartActivity: Number(this.data.editRedHeart || 0),
        socialPractice: Number(this.data.editSocialPractice || 0),
        internationalExchange: Number(this.data.editInterExchange || 0),
        peerMutualAid: Number(this.data.editPeerHelp || 0),
        inappropriateRemarks: Number(this.data.editWrongSpeech || 0),
        failedCourse: Number(this.data.editFailCourse || 0),
        unexcusedAbsence: Number(this.data.editAbsent || 0),
        networkViolation: Number(this.data.editNetViolate || 0),
        disciplinarySanction: Number(this.data.editDisciplinePunish || 0),
        oneVoteVeto: Number(this.data.editOneVoteVeto || 0)
      },
      success: function () {
        wx.hideLoading();
        wx.showToast({ title: "修改成功" });
        var content = "编辑党员积分：" + editRealName + "（" + editTerm + "）";
        this.addLog(content);
        this.setData({ showEdit: false });
        this.getAllScore();
      }.bind(this),
      fail: function () {
        wx.hideLoading();
        wx.showToast({ title: "保存失败", icon: "none" });
      }
    });
  },

  delScore: function (e) {
    var _id = e.currentTarget.dataset.id;
    wx.showModal({
      title: "确认删除",
      content: "删除后无法恢复，确定吗？",
      success: function (res) {
        if (!res.confirm) return;
        wx.showLoading({ title: "删除中" });
        wx.cloud.callFunction({
          name: "crud-score",
          data: { action: "deleteScore", _id: _id },
          success: function () {
            wx.hideLoading();
            wx.showToast({ title: "已删除" });
            var content = "删除积分记录，ID：" + _id;
            this.addLog(content);
            this.getAllScore();
          }.bind(this),
          fail: function () {
            wx.hideLoading();
            wx.showToast({ title: "删除失败", icon: "none" });
          }
        });
      }.bind(this)
    });
  },

  noop: function () {},

  addLog: function (content) {
    var admin = wx.getStorageSync("userInfo");
    if (!admin || !admin.realName) return;
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "add",
        adminName: admin.realName,
        operateContent: content
      }
    });
  }
})