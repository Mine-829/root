Page({
  data: {
    searchKey: "",
    yearOptions: [],
    selectYearIndex: 0,
    selectYear: "",
    allData: [],
    showList: [],
    loading: false,
    page: 1,
    pageSize: 15,
    noMore: false,
    navigating: false
  },

  onLoad: function () {
    this.loadData();
  },

  onUnload: function () {
    clearTimeout(this.yearTimer);
  },

  onSearchInput: function (e) {
    var val = e.detail.value;
    var that = this;
    this.setData({
      searchKey: val
    }, function () {
      that.filterList();
    });
  },

  onYearChange: function (e) {
    var idx = e.detail.value;
    var selectedText = this.data.yearOptions[idx];
    var realYear = selectedText === "全部入学年份" ? "" : selectedText;
    clearTimeout(this.yearTimer);
    var that = this;
    this.yearTimer = setTimeout(function () {
      that.setData({
        selectYearIndex: idx,
        selectYear: realYear
      }, function () {
        that.filterList();
      });
    }, 100);
  },

  filterList: function () {
    var key = this.data.searchKey.trim();
    var selectYear = this.data.selectYear;
    var temp = [].concat(this.data.allData);

    // 入学年份筛选
    if (selectYear && selectYear !== "") {
      var year = Number(selectYear);
      var newTemp = [];
      for (var i = 0; i < temp.length; i++) {
        var item = temp[i];
        var sid = Number(item.studentId || 0);
        if (sid < 10000) continue;
        var stuYear = Math.floor(sid / 100000000);
        if (stuYear === year) {
          newTemp.push(item);
        }
      }
      temp = newTemp;
    }

    // 搜索过滤
    if (key) {
      var searchTemp = [];
      if (/^\d{4}$/.test(key)) {
        var year = Number(key);
        for (var j = 0; j < temp.length; j++) {
          var itemJ = temp[j];
          var sidJ = Number(itemJ.studentId || 0);
          if (sidJ < 10000) continue;
          var stuYearJ = Math.floor(sidJ / 100000000);
          if (stuYearJ === year) {
            searchTemp.push(itemJ);
          }
        }
      } else {
        for (var k = 0; k < temp.length; k++) {
          var itemK = temp[k];
          var nameMatch = itemK.realName.indexOf(key) > -1;
          var classMatch = itemK.className.indexOf(key) > -1;
          var idMatch = String(itemK.studentId).indexOf(key) > -1;
          if (nameMatch || classMatch || idMatch) {
            searchTemp.push(itemK);
          }
        }
      }
      temp = searchTemp;
    }

    // 学号去重（ES5 普通for循环，无for-of）
    var idMap = new Map();
    var uniqueList = [];
    for (var m = 0; m < temp.length; m++) {
      var itemM = temp[m];
      var sidM = itemM.studentId;
      if (!idMap.has(sidM)) {
        idMap.set(sidM, true);
        uniqueList.push(itemM);
      }
    }

    // 无筛选条件时，中文姓名拼音升序排序
    if (!key && !selectYear) {
      uniqueList.sort(function (a, b) {
        return a.realName.localeCompare(b.realName, "zh-CN");
      });
    }

    this.setData({
      showList: uniqueList
    });
  },

  loadData: function () {
    if (this.data.loading || this.data.noMore) return;
    var that = this;
    that.setData({
      loading: true
    });
    wx.showLoading({
      title: "加载中"
    });
    wx.cloud.callFunction({
      name: "crud-score",
      data: {
        action: "getAllDesc"
      },
      success: function (res) {
        wx.hideLoading();
        that.setData({
          loading: false
        });
        if (res.result.code !== 0) {
          wx.showToast({
            title: res.result.msg,
            icon: "none"
          });
          return;
        }
        var arr = res.result.data || [];

        // 提取入学年份下拉选项
        var yearSet = new Set();
        for (var i = 0; i < arr.length; i++) {
          var item = arr[i];
          var sid = Number(item.studentId || 0);
          if (sid >= 10000) {
            var y = Math.floor(sid / 100000000);
            yearSet.add(String(y));
          }
        }
        var yearArr = Array.from(yearSet).sort(function (a, b) {
          return Number(a) - Number(b);
        });
        var displayList = ["全部入学年份"].concat(yearArr);

        that.setData({
          allData: arr,
          yearOptions: displayList,
          selectYearIndex: 0,
          selectYear: "",
          noMore: true,
          page: 1
        }, function () {
          that.filterList();
        });
      },
      fail: function () {
        wx.hideLoading();
        that.setData({
          loading: false
        });
        wx.showToast({
          title: "数据加载失败",
          icon: "none"
        });
      }
    });
  },

  loadMore: function () {
    return;
  },

  goPortrait: function (e) {
    if (this.data.navigating) return;
    var studentId = e.currentTarget.dataset.studentId;
    if (!studentId) {
      wx.showToast({
        title: "获取学号失败",
        icon: "none"
      });
      return;
    }
    var that = this;
    this.setData({
      navigating: true
    });
    wx.navigateTo({
      url: "/pages/admin-portrait/admin-portrait?targetStudentId=" + studentId,
      complete: function () {
        setTimeout(function () {
          that.setData({
            navigating: false
          });
        }, 300);
      }
    });
  }
});