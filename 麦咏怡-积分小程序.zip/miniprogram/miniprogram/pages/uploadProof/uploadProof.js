Page({
  data: {
    tempFilePaths: [],
    tempDocPaths: [],
    content: "",
    showTypePopup: false,
    materialType: "",
    materialTypeIndex: -1,
    tempSelectIndex: -1,
    materialTypeList: [
      "学业成长积分",
      "党务成长积分",
      "交流互助积分",
      "其他佐证材料"
    ]
  },

  noop: function () {},

  openPopup: function () {
    this.setData({
      showTypePopup: true,
      tempSelectIndex: this.data.materialTypeIndex
    })
  },

  closeMask: function () {
    this.setData({ showTypePopup: false })
  },

  pickType: function (e) {
    var idx = e.currentTarget.dataset.index
    this.setData({ tempSelectIndex: idx })
  },

  hidePopup: function () {
    this.setData({ showTypePopup: false })
  },

  confirmType: function () {
    var idx = this.data.tempSelectIndex
    if (idx === -1) {
      wx.showToast({ title: "请选择一项", icon: "none" })
      return
    }
    var selectText = this.data.materialTypeList[idx]
    this.setData({
      materialTypeIndex: idx,
      materialType: selectText,
      showTypePopup: false
    })
  },

  selectFile: function () {
    var that = this
    wx.chooseMedia({
      count: 3,
      mediaType: ["image"],
      sourceType: ["album"],
      success: function (res) {
        var paths = res.tempFiles.map(function (item) {
          return item.tempFilePath
        })
        var newList = that.data.tempFilePaths.concat(paths)
        that.setData({ tempFilePaths: newList })
      },
      fail: function () {
        wx.showToast({ title: "选择图片失败", icon: "none" })
      }
    })
  },

  selectDocument: function () {
    var that = this
    wx.chooseMessageFile({
      count: 2,
      type: "file",
      success: function (res) {
        var paths = res.tempFiles.map(function (item) {
          return item.path
        })
        var newDocList = that.data.tempDocPaths.concat(paths)
        that.setData({ tempDocPaths: newDocList })
      },
      fail: function () {
        wx.showToast({ title: "选择文件失败", icon: "none" })
      }
    })
  },

  delImg: function (e) {
    var index = e.currentTarget.dataset.index
    var arr = this.data.tempFilePaths
    arr.splice(index, 1)
    this.setData({ tempFilePaths: arr })
  },

  delDoc: function (e) {
    var index = e.currentTarget.dataset.index
    var arr = this.data.tempDocPaths
    arr.splice(index, 1)
    this.setData({ tempDocPaths: arr })
  },

  inputContent: function (e) {
    this.setData({ content: e.detail.value })
  },

  submitProof: function () {
    var data = this.data
    var loginUser = wx.getStorageSync("userInfo")

    if (!loginUser || !loginUser._id) {
      wx.showToast({ title: "请先登录", icon: "none" })
      setTimeout(function () {
        wx.reLaunch({ url: "/pages/login/login" })
      }, 1200)
      return
    }
    if (!data.materialType) {
      wx.showToast({ title: "请选择材料类型", icon: "none" })
      return this.openPopup()
    }
    if (!data.content) {
      return wx.showToast({ title: "请填写材料说明", icon: "none" })
    }
    if (data.tempFilePaths.length === 0 && data.tempDocPaths.length === 0) {
      return wx.showToast({ title: "请上传图片或文件", icon: "none" })
    }

    var that = this
    wx.showLoading({ title: "提交中..." })

    var imgFileIds = []
    var docFileIds = []
    var imgCount = data.tempFilePaths.length
    var docCount = data.tempDocPaths.length
    var total = imgCount + docCount
    var finish = 0

    function done() {
      finish++
      if (finish < total) return

      wx.cloud.callFunction({
        name: "material-audit",
        data: {
          action: "submit",
          userId: loginUser._id,
          realName: loginUser.realName,
          studentId: loginUser.studentId,
          className: loginUser.className,
          type: data.materialType,
          content: data.content,
          imgFileIds: imgFileIds,
          docFileIds: docFileIds
        },
        success: function (res) {
          wx.hideLoading()
          if (res.result.code === 0) {
            wx.showToast({ title: "提交成功" })
            setTimeout(function () {
              wx.navigateBack()
            }, 1500)
          } else {
            wx.showToast({ title: res.result.msg, icon: "none" })
          }
        },
        fail: function (err) {
          wx.hideLoading()
          wx.showToast({ title: "提交失败", icon: "none" })
          console.error(err)
        }
      })
    }

    for (var i = 0; i < imgCount; i++) {
      var path = data.tempFilePaths[i]
      var cloudPath = "proof/img/" + Date.now() + "-" + Math.random().toString(36) + ".png"
      wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: path,
        success: function (res) {
          imgFileIds.push(res.fileID)
          done()
        }
      })
    }

    for (var j = 0; j < docCount; j++) {
      var path = data.tempDocPaths[j]
      var cloudPath = "proof/doc/" + Date.now() + "-" + Math.random().toString(36)
      wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: path,
        success: function (res) {
          docFileIds.push(res.fileID)
          done()
        }
      })
    }
  }
})