Page({
  // 1.党员积分管理
  toScore() {
    wx.navigateTo({
      url: "/pages/admin-score/admin-score"
    })
  },
  // 2.作证材料审核
  toMaterial() {
    wx.navigateTo({
      url: "/pages/admin-material/admin-material"
    })
  },
  // 3.党课会议纪要
  toMeeting() {
    wx.navigateTo({
      url: "/pages/admin-meeting/admin-meeting"
    })
  },
  // 4.党员用户画像（跳转到党员列表选择页）
  toPortrait() {
    wx.navigateTo({
      url: "/pages/admin-user-list/admin-user-list"
    })
  },
  // 5.账号权限管理
  toUserManage() {
    wx.navigateTo({
      url: "/pages/admin-user/admin-user"
    })
  },
  // 6.Excel批量导入积分
  toExcelImport() {
    wx.navigateTo({
      url: "/pages/admin-excel-import/admin-excel-import"
    })
  },
  // 7.全操作留痕日志
  toLog() {
    wx.navigateTo({
      url: "/pages/admin-log/admin-log"
    })
  },
  // 8.退出登录
  logout() {
    // 清除本地存储的登录用户信息
    wx.removeStorageSync("userInfo")
    // 关闭所有页面，跳转登录页，禁止返回后台
    wx.reLaunch({
      url: "/pages/login/login"
    })
  },
  // 页面内完整正确的日志方法
addLog(content) {
  const admin = wx.getStorageSync("userInfo")
  wx.cloud.callFunction({
    name: "operation-log",
    data: {
      type: "add",
      adminName: admin.realName,
      operateContent: content
    }
  })
},
  
})