Page({
  data: {
    materialList: [],
    hideDocIds: []
  },
  onLoad: function () {
    var hideIds = wx.getStorageSync("hideMaterialIds") || [];
    this.setData({
      hideDocIds: hideIds
    });
    this.loadAllMaterial();
  },
  loadAllMaterial: function () {
    var that = this;
    wx.showLoading({
      title: "加载数据中..."
    });
    wx.cloud.callFunction({
      name: "material-audit",
      data: {
        action: "listAll"
      },
      success: function (res) {
        wx.hideLoading();
        if (res.result.code === 0) {
          var rawList = res.result.data;
          var filterList = [];
          // ES5循环过滤隐藏ID，不使用箭头/扩展运算符
          for (var i = 0; i < rawList.length; i++) {
            var item = rawList[i];
            var isHide = false;
            for (var j = 0; j < that.data.hideDocIds.length; j++) {
              if (that.data.hideDocIds[j] === item._id) {
                isHide = true;
                break;
              }
            }
            if (!isHide) {
              filterList.push(item);
            }
          }
          that.setData({
            materialList: filterList
          });
        } else {
          wx.showToast({
            title: res.result.msg,
            icon: "none"
          });
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: "数据加载失败",
          icon: "none"
        });
      }
    })
  },
  handleAgree: function (e) {
    var that = this;
    var docId = e.currentTarget.dataset.docId;
    var adminInfo = wx.getStorageSync("userInfo");
    wx.showModal({
      title: "确认同意",
      content: "确认通过该学生佐证材料审核？",
      success: function (res) {
        if (!res.confirm) return;
        wx.showLoading({
          title: "处理中..."
        });
        wx.cloud.callFunction({
          name: "material-audit",
          data: {
            action: "audit",
            _id: docId,
            status: "agree",
            auditBy: adminInfo.realName
          },
          success: function (res) {
            wx.hideLoading();
            if (res.result.code === 0) {
              wx.showToast({
                title: "审核已通过"
              });
              that.loadAllMaterial();
            } else {
              wx.showToast({
                title: res.result.msg,
                icon: "none"
              });
            }
          },
          fail: function () {
            wx.hideLoading();
            wx.showToast({
              title: "操作失败",
              icon: "none"
            });
          }
        })
      }
    })
  },
  handleReject: function (e) {
    var that = this;
    var docId = e.currentTarget.dataset.docId;
    var adminInfo = wx.getStorageSync("userInfo");
    wx.showModal({
      title: "确认驳回",
      content: "确认驳回该学生佐证材料？",
      success: function (res) {
        if (!res.confirm) return;
        wx.showLoading({
          title: "处理中..."
        });
        wx.cloud.callFunction({
          name: "material-audit",
          data: {
            action: "audit",
            _id: docId,
            status: "reject",
            auditBy: adminInfo.realName
          },
          success: function (res) {
            wx.hideLoading();
            if (res.result.code === 0) {
              wx.showToast({
                title: "已驳回"
              });
              that.loadAllMaterial();
            } else {
              wx.showToast({
                title: res.result.msg,
                icon: "none"
              });
            }
          },
          fail: function () {
            wx.hideLoading();
            wx.showToast({
              title: "操作失败",
              icon: "none"
            });
          }
        })
      }
    })
  },
  hideCardLocal: function (e) {
    var that = this;
    var targetDocId = e.currentTarget.dataset.docId;
    wx.showModal({
      title: "永久隐藏本条卡片",
      content: "隐藏后刷新页面、重新进入都不会再展示，数据库数据不会删除",
      success: function (res) {
        if (!res.confirm) return;
        // ES5 数组复制，替换 [...arr]
        var newHideIds = [];
        for (var i = 0; i < that.data.hideDocIds.length; i++) {
          newHideIds.push(that.data.hideDocIds[i]);
        }
        // 判断是否已存在，替代Set去重
        var exist = false;
        for (var k = 0; k < newHideIds.length; k++) {
          if (newHideIds[k] === targetDocId) {
            exist = true;
            break;
          }
        }
        if (!exist) {
          newHideIds.push(targetDocId);
        }
        // 本地持久化
        wx.setStorageSync("hideMaterialIds", newHideIds);
        that.setData({
          hideDocIds: newHideIds
        });
        // 前端实时过滤列表
        var newList = [];
        for (var m = 0; m < that.data.materialList.length; m++) {
          var item = that.data.materialList[m];
          if (item._id !== targetDocId) {
            newList.push(item);
          }
        }
        that.setData({
          materialList: newList
        });
        wx.showToast({
          title: "已永久隐藏"
        });
      }
    })
  },
  previewImage: function (e) {
    var urlList = e.currentTarget.dataset.urls;
    var index = e.currentTarget.dataset.index;
    wx.previewImage({
      urls: urlList,
      current: urlList[index]
    })
  },
  previewDoc: function (e) {
    var fileUrl = e.currentTarget.dataset.fileurl;
    wx.showLoading({
      title: "打开文件中..."
    });
    wx.downloadFile({
      url: fileUrl,
      success: function (res) {
        wx.hideLoading();
        var tempPath = res.tempFilePath;
        wx.openDocument({
          filePath: tempPath,
          success: function () {},
          fail: function () {
            wx.showToast({
              title: "该文件格式无法预览",
              icon: "none"
            });
          }
        })
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: "文件下载失败，无法预览",
          icon: "none"
        });
      }
    })
  }
})