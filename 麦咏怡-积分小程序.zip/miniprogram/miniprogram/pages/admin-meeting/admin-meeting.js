import { adminAuth } from "../../utils/auth"

Page({
  data: {
    title: "",
    content: "",
    meetingList: []
  },

  onShow() {
    const cache = wx.getStorageSync("userInfo")
    console.log("完整缓存：", cache)
    console.log("缓存类型：", typeof cache)
    console.log("role：", cache?.role)
    if (!adminAuth()) return
    this.getMeetingList()
  },

  inputTitle(e) { this.setData({ title: e.detail.value }) },
  inputContent(e) { this.setData({ content: e.detail.value }) },

  // 保存会议
  saveMeeting() {
    const { title, content } = this.data
    const admin = wx.getStorageSync("userInfo")

    if (!title || !content) {
      wx.showToast({ title: "不能为空", icon: "none" })
      return
    }

    wx.showLoading({ title: "保存中" })
    wx.cloud.callFunction({
      name: "meeting-record",
      data: { type: "add", title, content, createBy: admin.realName },
      success: (res) => {
        wx.hideLoading()
        if (res.result.code === 0) {
          // 调用独立日志云函数记录操作
          this.addLog(`新增会议：${title}`)
          this.setData({ title: "", content: "" })
          this.getMeetingList()
          wx.showToast({ title: "保存成功" })
        }
      },
      fail: () => {
        wx.hideLoading()
        wx.showToast({ title: "保存失败", icon: "none" })
      }
    })
  },

  // 获取列表
  getMeetingList() {
    wx.cloud.callFunction({
      name: "meeting-record",
      data: { type: "list" },
      success: (res) => {
        this.setData({ meetingList: res.result.data || [] })
      }
    })
  },

  // 删除会议
  delMeeting(e) {
    const { id, title } = e.currentTarget.dataset
    wx.showModal({
      content: `确定删除【${title}】？`,
      success: (res) => {
        if (res.confirm) {
          wx.cloud.callFunction({
            name: "meeting-record",
            data: { type: "del", _id: id },
            success: () => {
              this.addLog(`删除会议：${title}`)
              this.getMeetingList()
              wx.showToast({ title: "已删除" })
            }
          })
        }
      }
    })
  },

  // 独立日志云函数调用（已修改）
  addLog(content) {
    const admin = wx.getStorageSync("userInfo")
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        adminName: admin.realName,
        operateContent: content
      }
    })
  },

  formatTime(timestamp) {
    if (!timestamp) return ""
    const d = new Date(timestamp)
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,0)}-${String(d.getDate()).padStart(2,0)} ${String(d.getHours()).padStart(2,0)}:${String(d.getMinutes()).padStart(2,0)}`
  }
})