Page({
  data: {
    userId: "",
    studentId: "",
    role: "",
    scoreList: [],
    xAxisData: [],
    yAxisData: [],
    latestTotal: 0,
    loading: false
  },
  onLoad() {
    let uid = wx.getStorageSync("userId")
    let stuId = wx.getStorageSync("studentId")
    let userRole = wx.getStorageSync("role")

    if (!uid) {
      const loginInfo = wx.getStorageSync("userInfo")
      if (loginInfo && loginInfo._id) {
        uid = loginInfo._id
        stuId = loginInfo.studentId || ""
        userRole = loginInfo.role || ""
        wx.setStorageSync("studentId", stuId)
        wx.setStorageSync("role", userRole)
      } else {
        wx.redirectTo({ url: "/pages/login/login" })
        return
      }
    }
    this.setData({
      userId: uid,
      studentId: stuId,
      role: userRole
    })
    this.getScoreData()
  },
  getScoreData: function () {
    var that = this
    if (that.data.loading) return
    that.setData({ loading: true })
    wx.showLoading({ title: "加载积分" })
    const loginInfo = wx.getStorageSync("userInfo")
    wx.cloud.callFunction({
      name: "crud-score",
      data: {
        action: "getUserScoreHistory",
        studentId: loginInfo.studentId
      },
      success: function (res) {
        wx.hideLoading()
        that.setData({ loading: false })
        if (res.result.code === 0) {
          const list = res.result.data || []
          that.setData({ scoreList: list })
          if (list.length > 0) {
            const timeArr = []
            const totalArr = []
            for (let i = 0; i < list.length; i++) {
              const item = list[i]
              timeArr.push(new Date(item.createTime).toLocaleDateString())
              totalArr.push(item.totalScore)
            }
            that.setData({
              xAxisData: timeArr,
              yAxisData: totalArr,
              latestTotal: list[list.length - 1].totalScore
            })
          }
        } else {
          wx.showToast({ title: res.result.msg, icon: "none" })
        }
      },
      fail: function (err) {
        wx.hideLoading()
        that.setData({ loading: false })
        wx.showToast({ title: "积分加载失败", icon: "none" })
        console.error("积分接口报错：", err)
      }
    })
  },
  goAdminPortrait: function () {
    var loginInfo = wx.getStorageSync("userInfo")
    // 校验当前登录用户学号，只能查看自己
    if (!this.data.studentId) {
      wx.showToast({ title: "未获取到学号信息", icon: "none" })
      return
    }
    // 只传本人学号，页面仅加载当前用户数据
    wx.navigateTo({
      url: "/pages/admin-portrait/admin-portrait?targetStudentId=" + this.data.studentId + "&realName=" + loginInfo.realName
    })
  },
  // 跳转佐证上传页面
  goUploadProof: function () {
    wx.navigateTo({
      url: "/pages/uploadProof/uploadProof"
    })
  }
})