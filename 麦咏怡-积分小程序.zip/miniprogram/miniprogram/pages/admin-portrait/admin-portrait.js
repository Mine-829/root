Page({
  data: {
    targetStudentId: null,
    userInfo: {},
    scoreHistory: [],
    materialList: [],
    portraitEval: {},
    chartX: [],
    chartY: [],
    loading: false
  },

  onLoad(options) {
    const sidStr = options.targetStudentId
    if (!sidStr) {
      wx.showToast({ title: "参数缺失", icon: "none" })
      return
    }
    const sid = Number(sidStr)
    this.setData({ targetStudentId: sid })
    this.getUserBaseBySid(sid)
  },

  getUserBaseBySid(studentId) {
    if (this.data.loading) return
    const that = this
    that.setData({ loading: true })
    wx.showLoading({ title: "加载档案" })

    wx.cloud.callFunction({
      name: "crud-score",
      data: { action: "getAllDesc" },
      success(res) {
        wx.hideLoading()
        that.setData({ loading: false })
        if (res.result.code !== 0) {
          wx.showToast({ title: "数据加载失败", icon: "none" })
          return
        }
        const allList = res.result.data || []
        const userAllRecord = allList.filter(item => item.studentId === studentId)
        if (userAllRecord.length === 0) {
          wx.showToast({ title: "该学号暂无积分数据", icon: "none" })
          return
        }
        const baseInfo = userAllRecord[0]
        that.setData({
          userInfo: {
            name: baseInfo.realName,
            className: baseInfo.className || "未填写班级"
          },
          scoreHistory: userAllRecord
        }, () => {
          const xArr = []
          const yArr = []
          userAllRecord.sort((a, b) => a.term.localeCompare(b.term))
          userAllRecord.forEach(item => {
            xArr.push(item.term)
            yArr.push(Number(item.totalScore || 0).toFixed(1))
          })
          that.setData({ chartX: xArr, chartY: yArr }, () => {
            if (xArr.length > 0) setTimeout(() => that.drawChart(), 500)
          })
        })
        that.getPortraitBySid(studentId)
        that.getMaterialBySid(studentId)
      },
      fail() {
        wx.hideLoading()
        that.setData({ loading: false })
        wx.showToast({ title: "网络异常", icon: "none" })
      }
    })
  },

  getPortraitBySid(studentId) {
    const that = this
    wx.cloud.callFunction({
      name: "user-portrait",
      data: { studentId },
      success(res) {
        if (res.result.code === 0) {
          that.setData({ portraitEval: res.result.data || {} })
        }
      }
    })
  },

  getMaterialBySid(studentId) {
    const that = this
    wx.cloud.callFunction({
      name: "material-crud",
      data: {
        action: "getUserMaterial",
        studentId
      },
      success(res) {
        if (res.result.code === 0) {
          that.setData({ materialList: res.result.data || [] })
        }
      }
    })
  },

  drawChart() {
    const that = this
    const ctx = wx.createCanvasContext("scoreChart")
    const canvasW = 320
    const canvasH = 320
    const padding = 60
    const maxScore = 100
    const xData = that.data.chartX
    const yData = that.data.chartY

    ctx.clearRect(0, 0, canvasW, canvasH)
    if (xData.length === 0) return

    const yTicks = [100, 75, 50, 25, 0]

    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, canvasH - padding - 10)
    ctx.setStrokeStyle("#dcdcdc")
    ctx.setLineWidth(2)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(padding, canvasH - padding - 10)
    ctx.lineTo(canvasW - padding, canvasH - padding - 10)
    ctx.stroke()

    ctx.setFontSize(12)
    ctx.setFillStyle("#666")
    for (let t = 0; t < yTicks.length; t++) {
      const val = yTicks[t]
      const tickY = canvasH - padding - 10 - (val / maxScore) * (canvasH - padding * 2 - 10)
      ctx.fillText(String(val), padding - 22, tickY + 4)
      ctx.setLineDash([8, 8])
      ctx.beginPath()
      ctx.moveTo(padding, tickY)
      ctx.lineTo(canvasW - padding, tickY)
      ctx.setStrokeStyle("#eeeeee")
      ctx.setLineWidth(1)
      ctx.stroke()
      ctx.setLineDash([])
    }

    const gridCount = 4
    const cellWidth = (canvasW - padding * 2) / gridCount
    for (let g = 1; g < gridCount; g++) {
      const x = padding + cellWidth * g
      ctx.setLineDash([8, 8])
      ctx.beginPath()
      ctx.moveTo(x, padding)
      ctx.lineTo(x, canvasH - padding - 10)
      ctx.setStrokeStyle("#eeeeee")
      ctx.setLineWidth(1)
      ctx.stroke()
      ctx.setLineDash([])
    }

    if (xData.length > 1) {
      ctx.beginPath()
      for (let p = 0; p < xData.length; p++) {
        const x = padding + cellWidth * p + cellWidth / 2
        const y = canvasH - padding - 10 - (yData[p] / maxScore) * (canvasH - padding * 2 - 10)
        p === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)
      }
      ctx.setStrokeStyle("#c81623")
      ctx.setLineWidth(3)
      ctx.stroke()
    }

    for (let d = 0; d < xData.length; d++) {
      const val = yData[d]
      const x = padding + cellWidth * d + cellWidth / 2
      const y = canvasH - padding - 10 - (val / maxScore) * (canvasH - padding * 2 - 10)
      ctx.beginPath()
      ctx.arc(x, y, 7, 0, 2 * Math.PI)
      ctx.setFillStyle("#c81623")
      ctx.fill()
      ctx.setFillStyle("#333")
      ctx.setFontSize(12)
      ctx.fillText(val, x + 20, y + 4)
    }
    ctx.draw()
  },

  addLog(content) {
    const admin = wx.getStorageSync("userInfo")
    if (!admin || !admin.realName) return
    wx.cloud.callFunction({
      name: "operation-log",
      data: {
        type: "add",
        adminName: admin.realName,
        operateContent: content
      }
    })
  }
})