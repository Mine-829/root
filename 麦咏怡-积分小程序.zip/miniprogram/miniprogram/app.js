App({
  onLaunch() {
    wx.cloud.init({
      env: "cloud1-d7g8homtt4ad90b72"
    })
  },
  globalData: {
    userInfo: null
  },
  getTermOptions() {
    const startYear = 2024
    const currentYear = new Date().getFullYear()
    const endYear = currentYear + 5
    const list = []
    for (let y = startYear; y < endYear; y++) {
      const yearText = `${y}-${y + 1}`
      list.push(`${yearText}上`)
      list.push(`${yearText}下`)
    }
    return list
  }
})
