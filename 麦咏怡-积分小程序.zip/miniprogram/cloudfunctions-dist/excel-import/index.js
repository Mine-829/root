"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorValues(e) { if (null != e) { var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"], r = 0; if (t) return t.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) return { next: function next() { return e && r >= e.length && (e = void 0), { value: e && e[r++], done: !e }; } }; } throw new TypeError(_typeof(e) + " is not iterable"); }
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
var cloud = require('wx-server-sdk');
var XLSX = require('xlsx');
// 初始化云环境
cloud.init({
  env: "cloud1-d7g8homtt4ad90b72"
});
var db = cloud.database();
var _ = db.command;

// 积分规则常量
var SCORE_CFG = {
  absentScore: 2,
  failCourseScore: 5,
  disciplineScore: 3,
  volunteerPerHour: 0.25,
  volunteerMax: 8,
  activityPerItem: 2,
  prizePerItem: 3,
  postScore: {
    "班长": 10,
    "团支书": 10,
    "部长": 8,
    "副部长": 6,
    "委员": 4,
    "助班": 3,
    "副班长": 3
  }
};

/**
 * 清洗文本：去除换行、制表、零宽非法字符
 */
function cleanSafeText(text) {
  if (text === null || text === undefined) return "";
  var str = String(text);
  str = str.replace(/[\x00-\x1F\x7F-\x9F\n\r\t\v\u200b\u200c\u200d]/g, "");
  return str.trim();
}

/**
 * 兼容表头前后空格获取单元格值
 */
function getCellValue(row, keyList) {
  var _iterator = _createForOfIteratorHelper(keyList),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var key = _step.value;
      if (row[key] !== undefined) return row[key];
      if (row[" ".concat(key)] !== undefined) return row[" ".concat(key)];
      if (row["".concat(key, " ")] !== undefined) return row["".concat(key)];
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return "";
}

/**
 * 解析排名 2/27 → 返回数字名次，空返回9999
 */
function parseRankText(rankStr) {
  var s = cleanSafeText(rankStr);
  if (!s || !s.includes('/')) return 9999;
  var num = s.split('/')[0].trim();
  return Number(num) || 9999;
}

/**
 * 志愿时长 5小时7分钟 → 小时浮点数
 */
function parseVolText(timeStr) {
  var s = cleanSafeText(timeStr);
  if (!s) return 0;
  var h = 0,
    m = 0;
  var hMatch = s.match(/(\d+)小时/);
  var mMatch = s.match(/(\d+)分钟/);
  if (hMatch) h = Number(hMatch[1]);
  if (mMatch) m = Number(m);
  return h + m / 60;
}

/**
 * 拆分活动/获奖条目，返回干净数组
 */
function splitItemList(str) {
  var s = cleanSafeText(str);
  if (!s) return [];
  var t = s.replace(/<br\s*\/?>/g, '、');
  return t.split(/、|，/).filter(function (item) {
    return cleanSafeText(item);
  });
}
exports.main = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(event) {
    var action, excelFileID, fileRes, buffer, workbook, firstSheet, dataList, successCount, failList, _loop, i, _t2, _t3;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          action = event.action, excelFileID = event.excelFileID;
          if (excelFileID) {
            _context2.n = 1;
            break;
          }
          return _context2.a(2, {
            code: -1,
            msg: "失败：未接收到上传文件ID"
          });
        case 1:
          _context2.p = 1;
          if (!(action === "batchImportRaw")) {
            _context2.n = 12;
            break;
          }
          _context2.n = 2;
          return cloud.downloadFile({
            fileID: excelFileID
          });
        case 2:
          fileRes = _context2.v;
          buffer = fileRes.fileContent;
          workbook = XLSX.read(buffer, {
            type: "buffer",
            raw: false
          });
          firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          dataList = XLSX.utils.sheet_to_json(firstSheet);
          if (!(!dataList || dataList.length === 0)) {
            _context2.n = 3;
            break;
          }
          return _context2.a(2, {
            code: -1,
            msg: "失败：Excel表格无有效数据"
          });
        case 3:
          _context2.p = 3;
          _context2.n = 4;
          return db.collection("excel_raw").where({
            _id: _.exists(true)
          }).remove();
        case 4:
          console.log("临时表excel_raw清空完成");
          _context2.n = 6;
          break;
        case 5:
          _context2.p = 5;
          _t2 = _context2.v;
          console.log("excel_raw不存在，跳过清空");
        case 6:
          successCount = 0;
          failList = [];
          _loop = /*#__PURE__*/_regenerator().m(function _loop() {
            var row, rowNum, realName, className, isAbsent, absent, isFail, failCourse, isDis, disciplinePunish, studyRank, scholarHonor, zongRank, subjectComp, postStr, postScore, hourTotal, volunteer, actArr, prizeArr, activityScore, innovateBiz, socialWork, writeData, _t;
            return _regenerator().w(function (_context) {
              while (1) switch (_context.p = _context.n) {
                case 0:
                  row = dataList[i];
                  rowNum = i + 2;
                  _context.p = 1;
                  // 基础字段清洗
                  realName = cleanSafeText(getCellValue(row, ["姓名"]));
                  className = cleanSafeText(getCellValue(row, ["班级"]));
                  if (realName) {
                    _context.n = 2;
                    break;
                  }
                  return _context.a(2, 1);
                case 2:
                  // ========== 第一步：加载扣分项（是否旷课/挂科/违纪）==========
                  isAbsent = cleanSafeText(getCellValue(row, ["是否旷课"])) === "是";
                  absent = isAbsent ? SCORE_CFG.absentScore : 0;
                  isFail = cleanSafeText(getCellValue(row, ["是否挂科"])) === "是";
                  failCourse = isFail ? SCORE_CFG.failCourseScore : 0;
                  isDis = cleanSafeText(getCellValue(row, ["是否违纪"])) === "是";
                  disciplinePunish = isDis ? SCORE_CFG.disciplineScore : 0; // ========== 第二步：加载成绩排名加分 ==========
                  studyRank = parseRankText(getCellValue(row, ["学习成绩排名"]));
                  scholarHonor = 0;
                  if (studyRank <= 10) scholarHonor = 10;else if (studyRank <= 20) scholarHonor = 7;else if (studyRank <= 35) scholarHonor = 4;else if (studyRank <= 50) scholarHonor = 1;
                  zongRank = parseRankText(getCellValue(row, ["综测排名"]));
                  subjectComp = zongRank <= 20 ? 8 : 0; // ========== 第三步：职位、志愿、活动、获奖完整业务逻辑 ==========
                  // 职位加分
                  postStr = cleanSafeText(getCellValue(row, ["职位（班级/部门）"]));
                  postScore = 0;
                  Object.entries(SCORE_CFG.postScore).forEach(function (_ref2) {
                    var _ref3 = _slicedToArray(_ref2, 2),
                      name = _ref3[0],
                      score = _ref3[1];
                    if (postStr.includes(name) && score > postScore) postScore = score;
                  });

                  // 志愿时长计算
                  hourTotal = parseVolText(getCellValue(row, ["志愿总时长"]));
                  volunteer = hourTotal * SCORE_CFG.volunteerPerHour;
                  if (volunteer > SCORE_CFG.volunteerMax) volunteer = SCORE_CFG.volunteerMax;

                  // 活动、获奖拆分统计条数
                  actArr = splitItemList(getCellValue(row, ["参与学校、学院的活动（请罗列）"]));
                  prizeArr = splitItemList(getCellValue(row, ["获奖情况"]));
                  activityScore = actArr.length * SCORE_CFG.activityPerItem;
                  innovateBiz = prizeArr.length * SCORE_CFG.prizePerItem;
                  socialWork = postScore + activityScore; // 组装入库对象：全部数值强制Number，字符串全清洗，无undefined/null
                  writeData = {
                    realName: realName,
                    className: className,
                    socialWork: Number(socialWork),
                    subjectComp: Number(subjectComp),
                    innovateBiz: Number(innovateBiz),
                    scholarHonor: Number(scholarHonor),
                    partyClass: 0,
                    volunteer: Number(volunteer),
                    redHeart: 0,
                    socialPractice: 0,
                    interExchange: 0,
                    peerHelp: 0,
                    wrongSpeech: 0,
                    failCourse: Number(failCourse),
                    absent: Number(absent),
                    netViolate: 0,
                    disciplinePunish: Number(disciplinePunish),
                    oneVoteNo: 0,
                    createTime: new Date()
                  }; // 单条写入数据库
                  _context.n = 3;
                  return db.collection("excel_raw").add({
                    data: writeData
                  });
                case 3:
                  successCount++;
                  console.log("\u7B2C".concat(rowNum, "\u884C\u3010").concat(realName, "\u3011\u5199\u5165\u6210\u529F"));
                  _context.n = 5;
                  break;
                case 4:
                  _context.p = 4;
                  _t = _context.v;
                  console.error("\u7B2C".concat(rowNum, "\u884C\u5199\u5165\u5931\u8D25\u8BE6\u60C5\uFF1A"), _t);
                  failList.push("\u7B2C".concat(rowNum, "\u884C\uFF1A").concat(_t.message));
                case 5:
                  return _context.a(2);
              }
            }, _loop, null, [[1, 4]]);
          });
          i = 0;
        case 7:
          if (!(i < dataList.length)) {
            _context2.n = 10;
            break;
          }
          return _context2.d(_regeneratorValues(_loop()), 8);
        case 8:
          if (!_context2.v) {
            _context2.n = 9;
            break;
          }
          return _context2.a(3, 9);
        case 9:
          i++;
          _context2.n = 7;
          break;
        case 10:
          if (!(failList.length === 0)) {
            _context2.n = 11;
            break;
          }
          return _context2.a(2, {
            code: 0,
            msg: "\u2705 \u8868\u683C\u89E3\u6790\u5B8C\u6210\uFF0C\u5171".concat(successCount, "\u6761\u539F\u59CB\u6570\u636E"),
            count: successCount
          });
        case 11:
          return _context2.a(2, {
            code: 0,
            msg: "\u6210\u529F".concat(successCount, "\u6761\uFF0C\u5931\u8D25").concat(failList.length, "\u6761\uFF1A\n").concat(failList.join('\n')),
            count: successCount
          });
        case 12:
          return _context2.a(2, {
            code: -99,
            msg: "不支持的操作类型"
          });
        case 13:
          _context2.p = 13;
          _t3 = _context2.v;
          console.error("云函数全局异常：", _t3);
          return _context2.a(2, {
            code: -1,
            msg: "解析失败：" + _t3.message
          });
      }
    }, _callee, null, [[3, 5], [1, 13]]);
  }));
  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();