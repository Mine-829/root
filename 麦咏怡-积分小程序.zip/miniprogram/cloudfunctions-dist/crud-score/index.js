"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorValues(e) { if (null != e) { var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"], r = 0; if (t) return t.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) return { next: function next() { return e && r >= e.length && (e = void 0), { value: e && e[r++], done: !e }; } }; } throw new TypeError(_typeof(e) + " is not iterable"); }
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var cloud = require('wx-server-sdk');
// 固定你的云开发环境ID
cloud.init({
  env: "cloud1-d7g8homtt4ad90b72"
});
var db = cloud.database();
var _ = db.command;

// 读取积分规则配置
function getScoreRule() {
  return _getScoreRule.apply(this, arguments);
} // 志愿时长提取，保留2位小数
function _getScoreRule() {
  _getScoreRule = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2() {
    var res;
    return _regenerator().w(function (_context3) {
      while (1) switch (_context3.n) {
        case 0:
          _context3.n = 1;
          return db.collection("scoreRule").doc("59d6db416a39843e0b85fb623a4b4f4a").get();
        case 1:
          res = _context3.v;
          return _context3.a(2, res.data.rules);
      }
    }, _callee2);
  }));
  return _getScoreRule.apply(this, arguments);
}
function extractHourNum(hourStr) {
  if (!hourStr || hourStr.trim() === '无') return 0;
  var totalHour = 0;
  var hourMatch = hourStr.match(/(\d+\.?\d*)\s*小时/);
  if (hourMatch) totalHour = Number(hourMatch[1]);
  return Number(totalHour.toFixed(2));
}

// 排名分数计算（匹配rules.rank）
function getRankScore(rankStr, rankRule) {
  if (!rankStr || rankStr.trim() === '无' || !rankStr.includes('/')) return 0;
  var arr = rankStr.split('/').map(Number);
  var current = arr[0];
  var total = arr[1];
  if (isNaN(current) || isNaN(total) || total === 0) return 0;
  var percent = current / total * 100;
  if (percent <= 5) return rankRule.top5;
  if (percent <= 10) return rankRule.top10;
  if (percent <= 20) return rankRule.top20;
  return 0;
}

// 奖项分级匹配，同一类同年只取最高分
function getLevelAwardScore(text, typeKey, levelAwardRule) {
  var ruleItem = levelAwardRule[typeKey];
  if (!ruleItem || !text || text.trim() === '无') return 0;
  var lvList = ruleItem.lv || [];
  var scList = ruleItem.sc || [];
  var max = 0;
  for (var i = 0; i < lvList.length; i++) {
    if (text.includes(lvList[i])) {
      if (scList[i] > max) max = scList[i];
    }
  }
  return max;
}

// 拆分获奖文本，分类归档
function splitAwards(awardStr) {
  var awards = {
    subject: [],
    innovate: [],
    scholarship: [],
    honor: [],
    sport: [],
    practice: []
  };
  if (!awardStr || awardStr.trim() === '无') return awards;
  var list = awardStr.split(/\d+\.|\n/).filter(function (item) {
    return item.trim();
  });
  list.forEach(function (item) {
    var s = item.trim();
    if (s.includes('奖学金')) awards.scholarship.push(s);else if (['优秀团员', '团干', '骨干', '学员', '志愿者之星', '标兵', '十佳'].some(function (k) {
      return s.includes(k);
    })) awards.honor.push(s);else if (['数学', '竞赛', '建模', '蓝桥'].some(function (k) {
      return s.includes(k);
    })) awards.subject.push(s);else if (['挑战杯', '创新创业', '创新大赛'].some(function (k) {
      return s.includes(k);
    })) awards.innovate.push(s);else if (['运动会', '赛事'].some(function (k) {
      return s.includes(k);
    })) awards.sport.push(s);else if (['三下乡', '百千万', '社会实践'].some(function (k) {
      return s.includes(k);
    })) awards.practice.push(s);
  });
  return awards;
}

// 拆分活动文本，分类归档
function splitActivity(actStr) {
  var acts = {
    partyClass: [],
    redAct: [],
    socialPractice: [],
    interExchange: [],
    peerHelp: []
  };
  if (!actStr || actStr.trim() === '无') return acts;
  var list = actStr.split(/\d+\.|\n/).filter(function (item) {
    return item.trim();
  });
  list.forEach(function (item) {
    var s = item.trim();
    if (['党课', '青马', '党校'].some(function (k) {
      return s.includes(k);
    })) acts.partyClass.push(s);else if (['红色', '升旗', '雷锋', '研学'].some(function (k) {
      return s.includes(k);
    })) acts.redAct.push(s);else if (['三下乡', '实践'].some(function (k) {
      return s.includes(k);
    })) acts.socialPractice.push(s);else if (['国际交流', '留学生'].some(function (k) {
      return s.includes(k);
    })) acts.interExchange.push(s);else acts.peerHelp.push(s);
  });
  return acts;
}

// 分组同年取最高奖项分
function calcGroupSum(arr, typeKey, levelAwardRule) {
  var map = new Map();
  arr.forEach(function (text) {
    var _text$match;
    var key = ((_text$match = text.match(/20\d{2}/)) === null || _text$match === void 0 ? void 0 : _text$match[0]) || "unk";
    var score = getLevelAwardScore(text, typeKey, levelAwardRule);
    if (!map.has(key) || score > map.get(key)) map.set(key, score);
  });
  var sum = 0;
  var _iterator = _createForOfIteratorHelper(map.values()),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var v = _step.value;
      sum += v;
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return sum;
}

// 各类奖项分数计算快捷函数
function calcSubjectSum(list, levelAwardRule) {
  return calcGroupSum(list, "学科竞赛", levelAwardRule);
}
function calcInnovateSum(list, levelAwardRule) {
  return calcGroupSum(list, "创新创业", levelAwardRule);
}
function calcScholarSum(list, levelAwardRule) {
  return calcGroupSum(list, "奖学金", levelAwardRule);
}
function calcHonorSum(list, levelAwardRule) {
  var sum = 0;
  list.forEach(function (t) {
    return sum += getLevelAwardScore(t, "荣誉称号", levelAwardRule);
  });
  return sum;
}
function calcPracticeSum(list, levelAwardRule) {
  return calcGroupSum(list, "社会实践成果", levelAwardRule);
}

// 明细数字汇总总分（批量/编辑共用，党性上限60）
function calcSumFromDetail(detail) {
  var acCap = 40;
  var ptCap = 60;
  var studyRaw = detail.socialWork + detail.subjectComp + detail.innovateBiz + detail.scholarHonor;
  var studyAbility = Math.min(studyRaw, acCap);
  var partyRaw = detail.partyClass + detail.volunteer + detail.redHeart + detail.socialPractice + detail.interExchange + detail.peerHelp;
  var partyGrow = Math.min(partyRaw, ptCap);
  var deductRaw = Math.abs(detail.wrongSpeech) + Math.abs(detail.failCourse) + Math.abs(detail.absent) + Math.abs(detail.netViolate) + Math.abs(detail.disciplinePunish);
  if (Number(detail.oneVoteNo) > 0) deductRaw = 100;
  var total = Number((studyAbility + partyGrow - deductRaw).toFixed(2));
  return {
    studyAbility: studyAbility,
    partyGrow: partyGrow,
    deductScore: deductRaw,
    total: total
  };
}

// 云函数主入口
exports.main = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(event) {
    var action, rule, row, scoreResult, userId, res, rawRes, rawList, success, failMsgArr, _iterator2, _step2, _loop, realName, className, detail, _calcSumFromDetail2, studyAbility, partyGrow, deductScore, total, _userId2, userQuery, list, _id, _detail, _calcSumFromDetail3, _studyAbility, _partyGrow, _deductScore, _total, dataList, _success, _failMsgArr, _iterator3, _step3, item, _detail2, _calcSumFromDetail4, _studyAbility2, _partyGrow2, _deductScore2, _total2, _userId3, _userQuery, writeSuccess, retry, _t4, _t5, _t6, _t7, _t8, _t9, _t0, _t1;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          action = typeof event === "string" ? event : event.action;
          _context2.p = 1;
          _context2.n = 2;
          return getScoreRule();
        case 2:
          rule = _context2.v;
          if (!(action === "calcRowScore")) {
            _context2.n = 3;
            break;
          }
          row = event.rowData;
          scoreResult = calcTotalFromRow(row, rule);
          scoreResult.total = Number((scoreResult.studyAbility + scoreResult.partyGrow - scoreResult.deductScore).toFixed(2));
          return _context2.a(2, {
            code: 0,
            msg: "积分计算完成",
            data: scoreResult
          });
        case 3:
          if (!(action === "getUserScoreHistory")) {
            _context2.n = 5;
            break;
          }
          userId = event.userId;
          _context2.n = 4;
          return db.collection("score").where({
            userId: userId
          }).orderBy("createTime", "asc").get();
        case 4:
          res = _context2.v;
          return _context2.a(2, {
            code: 0,
            msg: "查询成功",
            data: res.data
          });
        case 5:
          if (!(action === "calcAllDevScore")) {
            _context2.n = 18;
            break;
          }
          _context2.n = 6;
          return db.collection("excel_raw").get();
        case 6:
          rawRes = _context2.v;
          rawList = rawRes.data;
          success = 0;
          failMsgArr = [];
          console.log("=== excel_raw完整数据 ===", JSON.stringify(rawList));
          console.log("=== excel_raw数据条数 ===", rawList.length);
          _iterator2 = _createForOfIteratorHelper(rawList);
          _context2.p = 7;
          _loop = /*#__PURE__*/_regenerator().m(function _loop() {
            var item, realVal, classVal, awardText, actText, postText, hourText, awards, acts, socialWorkScore, subScore, innovScore, scholScore, honorScore, partyScore, redScore, pracActScore, interScore, peerScore, volNum, volScore, fail, absent, disPunish, detail, _calcSumFromDetail, studyAbility, partyGrow, deductScore, total, _userId, userQuery, insertData, writeSuccess, retry, errName, _t, _t2, _t3;
            return _regenerator().w(function (_context) {
              while (1) switch (_context.p = _context.n) {
                case 0:
                  item = _step2.value;
                  _context.p = 1;
                  realVal = item.name || item['姓名'] || item['学生姓名'] || item['姓名 '] || item.xingming || "";
                  classVal = item.className || item['班级'] || item['班级 '] || item.banji || "";
                  console.log("=== 读取到的姓名 ===", realVal);
                  console.log("=== 读取到的班级 ===", classVal);
                  awardText = item.award || item['获奖情况'] || item['获奖情况 '] || '无';
                  actText = item.activity || item['参与学校、学院的活动（请罗列）'] || '无';
                  postText = item.position || item['职位（班级/部门）'] || '无';
                  hourText = item.volHour || item['志愿总时长'] || '无';
                  awards = splitAwards(awardText);
                  acts = splitActivity(actText);
                  socialWorkScore = 0;
                  Object.entries(rule.socialWork).forEach(function (_ref2) {
                    var _ref3 = _slicedToArray(_ref2, 2),
                      k = _ref3[0],
                      v = _ref3[1];
                    if (postText.includes(k)) socialWorkScore = v;
                  });
                  subScore = calcSubjectSum(awards.subject, rule.levelAward);
                  innovScore = calcInnovateSum(awards.innovate, rule.levelAward);
                  scholScore = calcScholarSum(awards.scholarship, rule.levelAward);
                  honorScore = calcHonorSum(awards.honor, rule.levelAward);
                  partyScore = acts.partyClass.length * rule.perActivity['党课学习'];
                  redScore = acts.redAct.length * rule.perActivity['红心活动'];
                  pracActScore = acts.socialPractice.length * rule.perActivity['社会实践'];
                  interScore = Math.min(acts.interExchange.length * rule.perActivity['国际交流'], rule.caps['国际交流']);
                  peerScore = acts.peerHelp.length * rule.perActivity['同辈互助'];
                  volNum = extractHourNum(hourText);
                  volScore = Math.min(volNum * rule.volunteer.rate, rule.volunteer.cap);
                  fail = item['是否挂科'] === '是' ? rule.discipline.fail : 0;
                  absent = item['是否旷课'] === '是' ? rule.discipline.warning : 0;
                  disPunish = item['是否违纪'] === '是' ? rule.discipline.severeWarning : 0;
                  detail = {
                    socialWork: socialWorkScore,
                    subjectComp: subScore,
                    innovateBiz: innovScore,
                    scholarHonor: scholScore + honorScore,
                    partyClass: partyScore,
                    volunteer: volScore,
                    redHeart: redScore,
                    socialPractice: pracActScore,
                    interExchange: interScore,
                    peerHelp: peerScore,
                    wrongSpeech: 0,
                    failCourse: fail,
                    absent: absent,
                    netViolate: 0,
                    disciplinePunish: disPunish,
                    oneVoteNo: 0
                  };
                  _calcSumFromDetail = calcSumFromDetail(detail), studyAbility = _calcSumFromDetail.studyAbility, partyGrow = _calcSumFromDetail.partyGrow, deductScore = _calcSumFromDetail.deductScore, total = _calcSumFromDetail.total;
                  _userId = "";
                  _context.p = 2;
                  _context.n = 3;
                  return db.collection("user").where({
                    name: realVal
                  }).get();
                case 3:
                  userQuery = _context.v;
                  _userId = userQuery.data.length ? userQuery.data[0]._id : "";
                  _context.n = 5;
                  break;
                case 4:
                  _context.p = 4;
                  _t = _context.v;
                case 5:
                  if (!_userId) _userId = "temp_".concat(Date.now(), "_").concat(Math.random().toString(36));
                  insertData = _objectSpread(_objectSpread({
                    realName: realVal,
                    "class": classVal
                  }, detail), {}, {
                    studyAbility: studyAbility,
                    partyGrow: partyGrow,
                    deductScore: deductScore,
                    total: total,
                    userId: _userId,
                    createTime: new Date(),
                    updateTime: new Date()
                  });
                  console.log("=== 待入库完整数据 ===", insertData);
                  if (!(!realVal || realVal.trim() === "")) {
                    _context.n = 6;
                    break;
                  }
                  throw new Error("学生姓名为空，跳过本条");
                case 6:
                  writeSuccess = false;
                  retry = 0;
                case 7:
                  if (!(retry < 3)) {
                    _context.n = 12;
                    break;
                  }
                  _context.p = 8;
                  _context.n = 9;
                  return db.collection("score").add(insertData);
                case 9:
                  writeSuccess = true;
                  return _context.a(3, 12);
                case 10:
                  _context.p = 10;
                  _t2 = _context.v;
                  _context.n = 11;
                  return new Promise(function (r) {
                    return setTimeout(r, 200);
                  });
                case 11:
                  retry++;
                  _context.n = 7;
                  break;
                case 12:
                  if (writeSuccess) {
                    _context.n = 13;
                    break;
                  }
                  throw new Error("写入三次失败");
                case 13:
                  success++;
                  _context.n = 14;
                  return new Promise(function (r) {
                    return setTimeout(r, 100);
                  });
                case 14:
                  _context.n = 16;
                  break;
                case 15:
                  _context.p = 15;
                  _t3 = _context.v;
                  errName = item.name || item['姓名'] || item['学生姓名'] || "无名";
                  failMsgArr.push("".concat(errName, "\uFF1A").concat(_t3.message));
                  console.error("=== 单行处理异常 ===", _t3);
                case 16:
                  return _context.a(2);
              }
            }, _loop, null, [[8, 10], [2, 4], [1, 15]]);
          });
          _iterator2.s();
        case 8:
          if ((_step2 = _iterator2.n()).done) {
            _context2.n = 10;
            break;
          }
          return _context2.d(_regeneratorValues(_loop()), 9);
        case 9:
          _context2.n = 8;
          break;
        case 10:
          _context2.n = 12;
          break;
        case 11:
          _context2.p = 11;
          _t4 = _context2.v;
          _iterator2.e(_t4);
        case 12:
          _context2.p = 12;
          _iterator2.f();
          return _context2.f(12);
        case 13:
          _context2.p = 13;
          _context2.n = 14;
          return db.collection("excel_raw").where({
            _id: _.exists(true)
          }).remove();
        case 14:
          _context2.n = 16;
          break;
        case 15:
          _context2.p = 15;
          _t5 = _context2.v;
          console.log("清空临时表异常", _t5);
        case 16:
          if (!(failMsgArr.length === 0)) {
            _context2.n = 17;
            break;
          }
          return _context2.a(2, {
            code: 0,
            msg: "\u2705 \u6210\u529F\u6279\u91CF\u751F\u6210".concat(success, "\u6761\u515A\u5458\u79EF\u5206\u8BB0\u5F55"),
            count: success
          });
        case 17:
          return _context2.a(2, {
            code: 0,
            msg: "\u6210\u529F".concat(success, "\u6761\uFF0C\u5931\u8D25").concat(failMsgArr.length, "\uFF1A\n").concat(failMsgArr.join('\n')),
            count: success,
            failList: failMsgArr
          });
        case 18:
          if (!(action === "addScore")) {
            _context2.n = 24;
            break;
          }
          realName = event.realName;
          className = event.className;
          detail = {
            socialWork: Number(event.socialWork || 0),
            subjectComp: Number(event.subjectComp || 0),
            innovateBiz: Number(event.innovateBiz || 0),
            scholarHonor: Number(event.scholarHonor || 0),
            partyClass: Number(event.partyClass || 0),
            volunteer: Number(event.volunteer || 0),
            redHeart: Number(event.redHeart || 0),
            socialPractice: Number(event.socialPractice || 0),
            interExchange: Number(event.interExchange || 0),
            peerHelp: Number(event.peerHelp || 0),
            wrongSpeech: Number(event.wrongSpeech || 0),
            failCourse: Number(event.failCourse || 0),
            absent: Number(event.absent || 0),
            netViolate: Number(event.netViolate),
            disciplinePunish: Number(event.disciplinePunish || 0),
            oneVoteNo: Number(event.oneVoteNo || 0)
          };
          _calcSumFromDetail2 = calcSumFromDetail(detail), studyAbility = _calcSumFromDetail2.studyAbility, partyGrow = _calcSumFromDetail2.partyGrow, deductScore = _calcSumFromDetail2.deductScore, total = _calcSumFromDetail2.total;
          _userId2 = "";
          _context2.p = 19;
          _context2.n = 20;
          return db.collection("user").where({
            name: realName.trim()
          }).get();
        case 20:
          userQuery = _context2.v;
          _userId2 = userQuery.data.length === 1 ? userQuery.data[0]._id : "";
          _context2.n = 22;
          break;
        case 21:
          _context2.p = 21;
          _t6 = _context2.v;
        case 22:
          _context2.n = 23;
          return db.collection("score").add(_objectSpread(_objectSpread({
            realName: realName.trim(),
            "class": className.trim()
          }, detail), {}, {
            studyAbility: studyAbility,
            partyGrow: partyGrow,
            interExchange: detail.interExchange,
            peerHelp: detail.peerHelp,
            deductScore: deductScore,
            total: total,
            userId: _userId2,
            createTime: new Date(),
            updateTime: new Date()
          }));
        case 23:
          return _context2.a(2, {
            code: 0,
            msg: "新增完成"
          });
        case 24:
          if (!(action === "getAllDesc" || action === "getScoreList")) {
            _context2.n = 26;
            break;
          }
          _context2.n = 25;
          return db.collection("score").get();
        case 25:
          res = _context2.v;
          list = res.data.map(function (item) {
            var _item$socialWork, _item$academicCompeti, _item$innovationEntre, _item$scholarshipHono, _item$partyClassStudy, _item$volunteer, _item$redHeartActivit, _item$socialPractice, _item$internationalEx, _item$peerMutualAid, _item$inappropriateRe, _item$failedCourse, _item$absent, _item$networkViolatio, _item$disciplinarySan, _item$oneVoteVeto, _item$academicCompeti2, _item$innovationEntre2, _item$partyClassStudy2, _item$redHeartActivit2, _item$internationalEx2, _item$peerMutualAid2, _item$disciplinarySan2, _item$inappropriateRe2, _item$oneVoteVeto2;
            var detail = {
              socialWork: (_item$socialWork = item.socialWork) !== null && _item$socialWork !== void 0 ? _item$socialWork : 0,
              subjectComp: (_item$academicCompeti = item.academicCompetition) !== null && _item$academicCompeti !== void 0 ? _item$academicCompeti : 0,
              innovateBiz: (_item$innovationEntre = item.innovationEntrepreneurship) !== null && _item$innovationEntre !== void 0 ? _item$innovationEntre : 0,
              scholarHonor: (_item$scholarshipHono = item.scholarshipHonor) !== null && _item$scholarshipHono !== void 0 ? _item$scholarshipHono : 0,
              partyClass: (_item$partyClassStudy = item.partyClassStudy) !== null && _item$partyClassStudy !== void 0 ? _item$partyClassStudy : 0,
              volunteer: (_item$volunteer = item.volunteer) !== null && _item$volunteer !== void 0 ? _item$volunteer : 0,
              redHeart: (_item$redHeartActivit = item.redHeartActivity) !== null && _item$redHeartActivit !== void 0 ? _item$redHeartActivit : 0,
              socialPractice: (_item$socialPractice = item.socialPractice) !== null && _item$socialPractice !== void 0 ? _item$socialPractice : 0,
              interExchange: (_item$internationalEx = item.internationalExchange) !== null && _item$internationalEx !== void 0 ? _item$internationalEx : 0,
              peerHelp: (_item$peerMutualAid = item.peerMutualAid) !== null && _item$peerMutualAid !== void 0 ? _item$peerMutualAid : 0,
              wrongSpeech: (_item$inappropriateRe = item.inappropriateRemarks) !== null && _item$inappropriateRe !== void 0 ? _item$inappropriateRe : 0,
              failCourse: (_item$failedCourse = item.failedCourse) !== null && _item$failedCourse !== void 0 ? _item$failedCourse : 0,
              absent: (_item$absent = item.absent) !== null && _item$absent !== void 0 ? _item$absent : 0,
              netViolate: (_item$networkViolatio = item.networkViolation) !== null && _item$networkViolatio !== void 0 ? _item$networkViolatio : 0,
              disciplinePunish: (_item$disciplinarySan = item.disciplinarySanction) !== null && _item$disciplinarySan !== void 0 ? _item$disciplinarySan : 0,
              oneVoteNo: (_item$oneVoteVeto = item.oneVoteVeto) !== null && _item$oneVoteVeto !== void 0 ? _item$oneVoteVeto : 0
            };
            var calcResult = calcSumFromDetail(detail);
            return _objectSpread(_objectSpread({}, item), {}, {
              studyAbility: calcResult.studyAbility,
              partyGrow: calcResult.partyGrow,
              deductScore: calcResult.deductScore,
              total: calcResult.total,
              subjectComp: (_item$academicCompeti2 = item.academicCompetition) !== null && _item$academicCompeti2 !== void 0 ? _item$academicCompeti2 : 0,
              innovateBiz: (_item$innovationEntre2 = item.innovationEntrepreneurship) !== null && _item$innovationEntre2 !== void 0 ? _item$innovationEntre2 : 0,
              partyClass: (_item$partyClassStudy2 = item.partyClassStudy) !== null && _item$partyClassStudy2 !== void 0 ? _item$partyClassStudy2 : 0,
              redHeart: (_item$redHeartActivit2 = item.redHeartActivity) !== null && _item$redHeartActivit2 !== void 0 ? _item$redHeartActivit2 : 0,
              interExchange: (_item$internationalEx2 = item.internationalExchange) !== null && _item$internationalEx2 !== void 0 ? _item$internationalEx2 : 0,
              peerHelp: (_item$peerMutualAid2 = item.peerMutualAid) !== null && _item$peerMutualAid2 !== void 0 ? _item$peerMutualAid2 : 0,
              disciplinePunish: (_item$disciplinarySan2 = item.disciplinarySanction) !== null && _item$disciplinarySan2 !== void 0 ? _item$disciplinarySan2 : 0,
              wrongSpeech: (_item$inappropriateRe2 = item.inappropriateRemarks) !== null && _item$inappropriateRe2 !== void 0 ? _item$inappropriateRe2 : 0,
              oneVoteNo: (_item$oneVoteVeto2 = item.oneVoteVeto) !== null && _item$oneVoteVeto2 !== void 0 ? _item$oneVoteVeto2 : 0
            });
          });
          list.sort(function (a, b) {
            return b.total - a.total;
          });
          return _context2.a(2, {
            code: 0,
            data: list,
            total: list.length
          });
        case 26:
          if (!(action === "updateScore")) {
            _context2.n = 28;
            break;
          }
          _id = event._id;
          _detail = {
            socialWork: Number(event.socialWork || 0),
            subjectComp: Number(event.subjectComp),
            innovateBiz: Number(event.innovateBiz || 0),
            scholarHonor: Number(event.scholarHonor || 0),
            partyClass: Number(event.partyClass || 0),
            volunteer: Number(event.volunteer || 0),
            redHeart: Number(event.redHeart || 0),
            socialPractice: Number(event.socialPractice || 0),
            interExchange: Number(event.interExchange || 0),
            peerHelp: Number(event.peerHelp || 0),
            wrongSpeech: Number(event.wrongSpeech || 0),
            failCourse: Number(event.failCourse || 0),
            absent: Number(event.absent || 0),
            netViolate: Number(event.netViolate || 0),
            disciplinePunish: Number(event.disciplinePunish || 0),
            oneVoteNo: Number(event.oneVoteNo || 0)
          };
          _calcSumFromDetail3 = calcSumFromDetail(_detail), _studyAbility = _calcSumFromDetail3.studyAbility, _partyGrow = _calcSumFromDetail3.partyGrow, _deductScore = _calcSumFromDetail3.deductScore, _total = _calcSumFromDetail3.total;
          _context2.n = 27;
          return db.collection("score").doc(_id).update({
            data: _objectSpread(_objectSpread({
              "class": event.className.trim()
            }, _detail), {}, {
              studyAbility: _studyAbility,
              partyGrow: _partyGrow,
              interExchange: _detail.interExchange,
              peerHelp: _detail.peerHelp,
              deductScore: _deductScore,
              total: _total,
              updateTime: new Date()
            })
          });
        case 27:
          return _context2.a(2, {
            code: 0,
            msg: "修改成功"
          });
        case 28:
          if (!(action === "deleteScore")) {
            _context2.n = 30;
            break;
          }
          _id = event._id;
          _context2.n = 29;
          return db.collection("score").doc(_id).remove();
        case 29:
          return _context2.a(2, {
            code: 0,
            msg: "删除成功"
          });
        case 30:
          if (!(action === "commonImportScore")) {
            _context2.n = 53;
            break;
          }
          dataList = event.list || [];
          if (!(!Array.isArray(dataList) || dataList.length === 0)) {
            _context2.n = 31;
            break;
          }
          return _context2.a(2, {
            code: -1,
            msg: "未传入有效导入数据"
          });
        case 31:
          _success = 0;
          _failMsgArr = [];
          _iterator3 = _createForOfIteratorHelper(dataList);
          _context2.p = 32;
          _iterator3.s();
        case 33:
          if ((_step3 = _iterator3.n()).done) {
            _context2.n = 49;
            break;
          }
          item = _step3.value;
          _context2.p = 34;
          _detail2 = {
            socialWork: Number(item.socialWork || 0),
            subjectComp: Number(item.subjectComp || 0),
            innovateBiz: Number(item.innovateBiz || 0),
            scholarHonor: Number(item.scholarHonor || 0),
            partyClass: Number(item.partyClass || 0),
            volunteer: Number(item.volunteer || 0),
            redHeart: Number(item.redHeart || 0),
            socialPractice: Number(item.socialPractice || 0),
            interExchange: Number(item.interExchange || 0),
            peerHelp: Number(item.peerHelp || 0),
            wrongSpeech: Number(item.wrongSpeech || 0),
            failCourse: Number(item.failCourse || 0),
            absent: Number(item.absent || 0),
            netViolate: Number(item.netViolate || 0),
            disciplinePunish: Number(item.disciplinePunish || 0),
            oneVoteNo: Number(item.oneVoteNo || 0)
          };
          _calcSumFromDetail4 = calcSumFromDetail(_detail2), _studyAbility2 = _calcSumFromDetail4.studyAbility, _partyGrow2 = _calcSumFromDetail4.partyGrow, _deductScore2 = _calcSumFromDetail4.deductScore, _total2 = _calcSumFromDetail4.total;
          _userId3 = "";
          _context2.p = 35;
          _context2.n = 36;
          return db.collection("user").where({
            name: item.realName
          }).get();
        case 36:
          _userQuery = _context2.v;
          _userId3 = _userQuery.data.length ? _userQuery.data[0]._id : "";
          _context2.n = 38;
          break;
        case 37:
          _context2.p = 37;
          _t7 = _context2.v;
          _userId3 = "";
        case 38:
          writeSuccess = false;
          retry = 0;
        case 39:
          if (!(retry < 3)) {
            _context2.n = 44;
            break;
          }
          _context2.p = 40;
          _context2.n = 41;
          return db.collection("score").add(_objectSpread(_objectSpread({
            realName: item.realName,
            "class": item.className || item["class"]
          }, _detail2), {}, {
            studyAbility: _studyAbility2,
            partyGrow: _partyGrow2,
            interExchange: _detail2.interExchange,
            peerHelp: _detail2.peerHelp,
            deductScore: _deductScore2,
            total: _total2,
            userId: _userId3,
            createTime: new Date(),
            updateTime: new Date()
          }));
        case 41:
          writeSuccess = true;
          return _context2.a(3, 44);
        case 42:
          _context2.p = 42;
          _t8 = _context2.v;
          _context2.n = 43;
          return new Promise(function (r) {
            return setTimeout(r, 300);
          });
        case 43:
          retry++;
          _context2.n = 39;
          break;
        case 44:
          if (writeSuccess) {
            _context2.n = 45;
            break;
          }
          throw new Error("三次写入均触发数据库限流");
        case 45:
          _success++;
          _context2.n = 46;
          return new Promise(function (r) {
            return setTimeout(r, 200);
          });
        case 46:
          _context2.n = 48;
          break;
        case 47:
          _context2.p = 47;
          _t9 = _context2.v;
          _failMsgArr.push("".concat(item.realName || "未知姓名", "\uFF1A").concat(_t9.message));
        case 48:
          _context2.n = 33;
          break;
        case 49:
          _context2.n = 51;
          break;
        case 50:
          _context2.p = 50;
          _t0 = _context2.v;
          _iterator3.e(_t0);
        case 51:
          _context2.p = 51;
          _iterator3.f();
          return _context2.f(51);
        case 52:
          return _context2.a(2, _failMsgArr.length === 0 ? {
            code: 0,
            msg: "\u2705 \u6210\u529F\u5BFC\u5165".concat(_success, "\u6761"),
            count: _success
          } : {
            code: 0,
            msg: "\u6210\u529F".concat(_success, "\u6761\uFF0C\u5931\u8D25").concat(_failMsgArr.length, "\uFF1A\n").concat(_failMsgArr.join('\n')),
            count: _success,
            failList: _failMsgArr
          });
        case 53:
          return _context2.a(2, {
            code: -99,
            msg: "无效操作类型"
          });
        case 54:
          _context2.p = 54;
          _t1 = _context2.v;
          console.error("=== 云函数全局错误 ===", _t1);
          return _context2.a(2, {
            code: -1,
            msg: "执行失败：" + _t1.message
          });
      }
    }, _callee, null, [[40, 42], [35, 37], [34, 47], [32, 50, 51, 52], [19, 21], [13, 15], [7, 11, 12, 13], [1, 54]]);
  }));
  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();