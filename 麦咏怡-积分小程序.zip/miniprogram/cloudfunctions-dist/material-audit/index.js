"use strict";

function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var cloud = require('wx-server-sdk');
cloud.init({
  env: "cloud1-d7g8homtt4ad90b72"
});
var db = cloud.database();
var _ = db.command;

// 云函数入口
exports.main = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(event, context) {
    var action, userId, projectId, formData, _t, _t2;
    return _regenerator().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          action = event.action, userId = event.userId, projectId = event.projectId, formData = event.formData;
          _context.p = 1;
          _t = action;
          _context.n = _t === 'getUserAllProject' ? 2 : _t === 'addProject' ? 4 : _t === 'deleteProject' ? 6 : _t === 'getProjectById' ? 8 : _t === 'getAllProject' ? 10 : 12;
          break;
        case 2:
          _context.n = 3;
          return getUserAllProject(userId);
        case 3:
          return _context.a(2, _context.v);
        case 4:
          _context.n = 5;
          return addProject(formData);
        case 5:
          return _context.a(2, _context.v);
        case 6:
          _context.n = 7;
          return deleteProject(projectId);
        case 7:
          return _context.a(2, _context.v);
        case 8:
          _context.n = 9;
          return getProjectById(projectId);
        case 9:
          return _context.a(2, _context.v);
        case 10:
          _context.n = 11;
          return getAllProject();
        case 11:
          return _context.a(2, _context.v);
        case 12:
          return _context.a(2, {
            code: -1,
            msg: '无效的action操作'
          });
        case 13:
          _context.n = 15;
          break;
        case 14:
          _context.p = 14;
          _t2 = _context.v;
          console.error('material-audit 执行错误：', _t2);
          return _context.a(2, {
            code: -999,
            msg: '服务器异常',
            error: _t2.message
          });
        case 15:
          return _context.a(2);
      }
    }, _callee, null, [[1, 14]]);
  }));
  return function (_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * 获取指定用户所有项目材料（画像页接口）
 * @param {string} userId 用户唯一标识
 */
function getUserAllProject(_x3) {
  return _getUserAllProject.apply(this, arguments);
}
/**
 * 新增项目实践材料
 * @param {object} formData 表单提交数据
 */
function _getUserAllProject() {
  _getUserAllProject = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2(userId) {
    var res;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.n) {
        case 0:
          _context2.n = 1;
          return db.collection('material_project').where({
            userId: userId
          }).orderBy('createTime', 'desc').get();
        case 1:
          res = _context2.v;
          return _context2.a(2, {
            code: 0,
            msg: '查询成功',
            data: res.data
          });
      }
    }, _callee2);
  }));
  return _getUserAllProject.apply(this, arguments);
}
function addProject(_x4) {
  return _addProject.apply(this, arguments);
}
/**
 * 删除项目材料
 * @param {string} projectId 项目文档_id
 */
function _addProject() {
  _addProject = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee3(formData) {
    var now, insertData, addRes;
    return _regenerator().w(function (_context3) {
      while (1) switch (_context3.n) {
        case 0:
          now = new Date();
          insertData = {
            userId: formData.userId,
            projectName: formData.projectName,
            content: formData.content,
            createTime: now,
            updateTime: now
          };
          _context3.n = 1;
          return db.collection('material_project').add({
            data: insertData
          });
        case 1:
          addRes = _context3.v;
          return _context3.a(2, {
            code: 0,
            msg: '提交成功',
            _id: addRes._id
          });
      }
    }, _callee3);
  }));
  return _addProject.apply(this, arguments);
}
function deleteProject(_x5) {
  return _deleteProject.apply(this, arguments);
}
/**
 * 根据项目ID查询单条详情
 * @param {string} projectId 项目文档_id
 */
function _deleteProject() {
  _deleteProject = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee4(projectId) {
    return _regenerator().w(function (_context4) {
      while (1) switch (_context4.n) {
        case 0:
          _context4.n = 1;
          return db.collection('material_project').doc(projectId).remove();
        case 1:
          return _context4.a(2, {
            code: 0,
            msg: '删除成功'
          });
      }
    }, _callee4);
  }));
  return _deleteProject.apply(this, arguments);
}
function getProjectById(_x6) {
  return _getProjectById.apply(this, arguments);
}
/**
 * 管理员获取全部项目（后台管理）
 */
function _getProjectById() {
  _getProjectById = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee5(projectId) {
    var res;
    return _regenerator().w(function (_context5) {
      while (1) switch (_context5.n) {
        case 0:
          _context5.n = 1;
          return db.collection('material_project').doc(projectId).get();
        case 1:
          res = _context5.v;
          return _context5.a(2, {
            code: 0,
            msg: '查询成功',
            data: res.data
          });
      }
    }, _callee5);
  }));
  return _getProjectById.apply(this, arguments);
}
function getAllProject() {
  return _getAllProject.apply(this, arguments);
}
function _getAllProject() {
  _getAllProject = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee6() {
    var res;
    return _regenerator().w(function (_context6) {
      while (1) switch (_context6.n) {
        case 0:
          _context6.n = 1;
          return db.collection('material_project').orderBy('createTime', 'desc').get();
        case 1:
          res = _context6.v;
          return _context6.a(2, {
            code: 0,
            msg: '查询成功',
            data: res.data
          });
      }
    }, _callee6);
  }));
  return _getAllProject.apply(this, arguments);
}