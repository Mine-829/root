"use strict";

function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var cloud = require('wx-server-sdk');
cloud.init({
  env: "cloud1-d7g8homtt4ad90b72"
});
var db = cloud.database();
var userColl = db.collection("user");
var logColl = db.collection("operation_log");
exports.main = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(event) {
    var action, name, pwd, realName, existRes, addResult, newUserId, _name, _pwd, _realName, userRes, list, targetId, newRole, operateAdmin, _realName2, _id, _t;
    return _regenerator().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          action = event.action;
          console.log("userCrud收到参数：", event);
          _context.p = 1;
          if (!(action === "register")) {
            _context.n = 7;
            break;
          }
          name = event.name, pwd = event.pwd;
          if (!(!name || !pwd)) {
            _context.n = 2;
            break;
          }
          return _context.a(2, {
            code: 1,
            msg: "姓名、密码不能为空"
          });
        case 2:
          realName = name.trim(); // 姓名查重，禁止重名注册
          _context.n = 3;
          return userColl.where({
            realName: realName
          }).get();
        case 3:
          existRes = _context.v;
          if (!(existRes.data.length > 0)) {
            _context.n = 4;
            break;
          }
          return _context.a(2, {
            code: -1,
            msg: "该姓名已注册，请勿重复注册"
          });
        case 4:
          _context.n = 5;
          return userColl.add({
            data: {
              realName: realName,
              password: pwd,
              role: "member",
              createTime: db.serverDate()
            }
          });
        case 5:
          addResult = _context.v;
          newUserId = addResult._id; // 核心逻辑：匹配score表 同realName、无userId的积分记录，批量绑定当前用户_id
          _context.n = 6;
          return db.collection("score").where({
            realName: realName,
            userId: db.command.exists(false)
          }).update({
            data: {
              userId: newUserId,
              updateTime: db.serverDate()
            }
          });
        case 6:
          return _context.a(2, {
            code: 0,
            msg: "注册成功，已自动匹配绑定你的积分记录"
          });
        case 7:
          if (!(action === "login")) {
            _context.n = 10;
            break;
          }
          _name = event.name, _pwd = event.pwd;
          _realName = _name.trim();
          _context.n = 8;
          return userColl.where({
            realName: _realName,
            password: _pwd
          }).get();
        case 8:
          userRes = _context.v;
          if (!(userRes.data.length === 0)) {
            _context.n = 9;
            break;
          }
          return _context.a(2, {
            code: 1,
            msg: "姓名或密码错误"
          });
        case 9:
          return _context.a(2, {
            code: 0,
            msg: "登录成功",
            userInfo: userRes.data[0]
          });
        case 10:
          if (!(action === "getAllUser" || action === "getUserList")) {
            _context.n = 12;
            break;
          }
          _context.n = 11;
          return userColl.orderBy("createTime", "desc").get();
        case 11:
          list = _context.v;
          return _context.a(2, {
            code: 0,
            data: list.data
          });
        case 12:
          if (!(action === "updateRole" || action === "admin-user")) {
            _context.n = 15;
            break;
          }
          targetId = event.targetId, newRole = event.newRole, operateAdmin = event.operateAdmin, _realName2 = event.realName;
          _context.n = 13;
          return userColl.doc(targetId).update({
            data: {
              role: newRole,
              updateBy: operateAdmin,
              updateTime: db.serverDate()
            }
          });
        case 13:
          _context.n = 14;
          return logColl.add({
            data: {
              adminName: operateAdmin,
              operateContent: "\u5C06\u7528\u6237\u3010".concat(_realName2, "\u3011\u89D2\u8272\u4FEE\u6539\u4E3A\uFF1A").concat(newRole === "admin" ? "支部管理员" : "普通党员"),
              operateTime: db.serverDate()
            }
          });
        case 14:
          return _context.a(2, {
            code: 0,
            msg: "角色权限修改完成"
          });
        case 15:
          if (!(action === "deleteUser")) {
            _context.n = 17;
            break;
          }
          _id = event._id;
          _context.n = 16;
          return userColl.doc(_id).remove();
        case 16:
          return _context.a(2, {
            code: 0,
            msg: "删除用户成功"
          });
        case 17:
          return _context.a(2, {
            code: -99,
            msg: "无效操作类型"
          });
        case 18:
          _context.p = 18;
          _t = _context.v;
          console.error("userCrud异常：", _t);
          return _context.a(2, {
            code: -2,
            msg: "操作失败",
            errDetail: _t.message
          });
      }
    }, _callee, null, [[1, 18]]);
  }));
  return function (_x) {
    return _ref.apply(this, arguments);
  };
}();