module.exports = {
  presets: [
    [
      "@babel/preset-env",
      {
        // 适配小程序最低基础库
        targets: {
          ios: "9",
          android: "6"
        },
        useBuiltIns: "runtime",
        corejs: 3
      }
    ]
  ],
  plugins: [
    [
      "@babel/plugin-transform-runtime",
      {
        corejs: 3
      }
    ]
  ]
}